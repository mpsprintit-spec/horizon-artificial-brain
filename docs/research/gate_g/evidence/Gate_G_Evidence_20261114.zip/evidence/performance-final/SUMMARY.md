# Gate G performance confirmation

Complete: **False**. Passed locked observed comparisons: **False** (81/90).

Values are means of per-run measurements. Raw samples/runs and every failed comparison remain in summary.json and the original logs.

| Workload | Metric | Baseline | Candidate | Limit | Result |
|---|---|---:|---:|---:|---|
| BenchmarkGateGThought/nodes=1000/dense=false/journal=false | thought_p95_ms | 1.22195 | 1.0793 | 1.50524 | PASS |
| BenchmarkGateGThought/nodes=1000/dense=false/journal=false | B/op | 29020.5 | 29002 | 34567.5 | PASS |
| BenchmarkGateGThought/nodes=1000/dense=false/journal=true | thought_p95_ms | 0.972 | 1.4815 | 1.2178 | FAIL |
| BenchmarkGateGThought/nodes=1000/dense=false/journal=true | B/op | 30730.5 | 30726.5 | 36363 | PASS |
| BenchmarkGateGThought/nodes=1000/dense=true/journal=false | thought_p95_ms | 11.1715 | 12.21 | 12.9472 | PASS |
| BenchmarkGateGThought/nodes=1000/dense=true/journal=false | B/op | 1.68329e+06 | 1.68342e+06 | 1.77155e+06 | PASS |
| BenchmarkGateGThought/nodes=1000/dense=true/journal=true | thought_p95_ms | 10.3335 | 12.835 | 11.9835 | FAIL |
| BenchmarkGateGThought/nodes=1000/dense=true/journal=true | B/op | 1.68519e+06 | 1.68511e+06 | 1.77355e+06 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=false/journal=false | thought_p95_ms | 2.6285 | 2.299 | 3.12277 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=false/journal=false | B/op | 29026 | 28963 | 34573.3 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=false/journal=true | thought_p95_ms | 2.79 | 1.7625 | 3.3085 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=false/journal=true | B/op | 30714.5 | 30717.5 | 36346.2 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=true/journal=false | thought_p95_ms | 44.755 | 47.085 | 51.5682 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=true/journal=false | B/op | 6.74448e+06 | 6.74486e+06 | 7.0858e+06 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=true/journal=true | thought_p95_ms | 56.96 | 92.915 | 65.604 | FAIL |
| BenchmarkGateGThought/nodes=4000/dense=true/journal=true | B/op | 6.74592e+06 | 6.7465e+06 | 7.08732e+06 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=false/journal=false | thought_p95_ms | 21.695 | 27.71 | 25.0493 | FAIL |
| BenchmarkGateGThought/nodes=40000/dense=false/journal=false | B/op | 28968.5 | 28998.5 | 34512.9 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=false/journal=true | thought_p95_ms | 22.475 | 26.24 | 25.9463 | FAIL |
| BenchmarkGateGThought/nodes=40000/dense=false/journal=true | B/op | 30696.5 | 30752 | 36327.3 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=true/journal=false | thought_p95_ms | 481.7 | 491.55 | 554.055 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=true/journal=false | B/op | 5.55567e+07 | 5.55565e+07 | 5.83386e+07 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=true/journal=true | thought_p95_ms | 514.9 | 568.3 | 592.235 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=true/journal=true | B/op | 5.55582e+07 | 5.55576e+07 | 5.83402e+07 | PASS |
| BenchmarkGateGContextContinuity/nodes=40000/dense=false/journal=true | thought_p95_ms | 50.37 | 31.545 | 58.0255 | PASS |
| BenchmarkGateGContextContinuity/nodes=40000/dense=false/journal=true | B/op | 561854 | 561780 | 594043 | PASS |
| BenchmarkGateGNativeStages/nodes=1000/dense=false | operation_p95_ms | 0.1889 | 0.1032 | 0.32668 | PASS |
| BenchmarkGateGNativeStages/nodes=1000/dense=false | learning_p95_ms | 0.095855 | 0.05552 | 0.215026 | PASS |
| BenchmarkGateGNativeStages/nodes=1000/dense=false | B/op | 91859.5 | 91110 | 105141 | PASS |
| BenchmarkGateGNativeStages/nodes=1000/dense=true | operation_p95_ms | 8.618 | 7.4725 | 10.4416 | PASS |
| BenchmarkGateGNativeStages/nodes=1000/dense=true | learning_p95_ms | 2.3435 | 2.0945 | 2.9122 | PASS |
| BenchmarkGateGNativeStages/nodes=1000/dense=true | B/op | 3.56077e+06 | 3.63368e+06 | 3.92095e+06 | PASS |
| BenchmarkGateGNativeStages/nodes=4000/dense=false | operation_p95_ms | 0.1527 | 0.2611 | 0.28324 | PASS |
| BenchmarkGateGNativeStages/nodes=4000/dense=false | learning_p95_ms | 0.10201 | 0.05719 | 0.222412 | PASS |
| BenchmarkGateGNativeStages/nodes=4000/dense=false | B/op | 91936.5 | 91049.5 | 105226 | PASS |
| BenchmarkGateGNativeStages/nodes=4000/dense=true | operation_p95_ms | 32 | 34.615 | 38.5 | PASS |
| BenchmarkGateGNativeStages/nodes=4000/dense=true | learning_p95_ms | 11.572 | 19.645 | 13.9864 | FAIL |
| BenchmarkGateGNativeStages/nodes=4000/dense=true | B/op | 1.42159e+07 | 1.45226e+07 | 1.56416e+07 | PASS |
| BenchmarkGateGNativeStages/nodes=40000/dense=false | operation_p95_ms | 0.1888 | 0.19845 | 0.32656 | PASS |
| BenchmarkGateGNativeStages/nodes=40000/dense=false | learning_p95_ms | 0.18615 | 0.05819 | 0.32338 | PASS |
| BenchmarkGateGNativeStages/nodes=40000/dense=false | B/op | 91962.5 | 91250 | 105255 | PASS |
| BenchmarkGateGNativeStages/nodes=40000/dense=true | operation_p95_ms | 458.5 | 534.7 | 550.3 | PASS |
| BenchmarkGateGNativeStages/nodes=40000/dense=true | learning_p95_ms | 128.5 | 154 | 154.3 | PASS |
| BenchmarkGateGNativeStages/nodes=40000/dense=true | B/op | 1.25626e+08 | 1.28666e+08 | 1.38193e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=1000/mode=checkpoint | ns/op | 1.96009e+07 | 2.40048e+07 | 2.36211e+07 | FAIL |
| BenchmarkNativeActionPersistence/nodes=1000/mode=checkpoint | B/op | 4.36763e+06 | 4.3673e+06 | 4.80849e+06 | PASS |
| BenchmarkNativeActionPersistence/nodes=1000/mode=restore-pending | ns/op | 2.58612e+08 | 2.64696e+08 | 3.10435e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=1000/mode=restore-pending | B/op | 2.62048e+07 | 2.62053e+07 | 2.88294e+07 | PASS |
| BenchmarkNativeActionPersistence/nodes=1000/mode=replay-pair | ns/op | 3.19335e+08 | 3.23766e+08 | 3.83303e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=1000/mode=replay-pair | B/op | 3.05103e+07 | 2.95007e+07 | 3.35654e+07 | PASS |
| BenchmarkNativeActionPersistence/nodes=4000/mode=checkpoint | ns/op | 9.01799e+07 | 7.87554e+07 | 1.08316e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=4000/mode=checkpoint | B/op | 1.63199e+07 | 1.63184e+07 | 1.7956e+07 | PASS |
| BenchmarkNativeActionPersistence/nodes=4000/mode=restore-pending | ns/op | 9.99065e+08 | 1.18353e+09 | 1.19898e+09 | PASS |
| BenchmarkNativeActionPersistence/nodes=4000/mode=restore-pending | B/op | 1.29941e+08 | 1.33931e+08 | 1.42939e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=4000/mode=replay-pair | ns/op | 1.25763e+09 | 1.28468e+09 | 1.50925e+09 | PASS |
| BenchmarkNativeActionPersistence/nodes=4000/mode=replay-pair | B/op | 1.42513e+08 | 1.38528e+08 | 1.56768e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=40000/mode=checkpoint | ns/op | 8.40975e+08 | 7.84138e+08 | 1.00927e+09 | PASS |
| BenchmarkNativeActionPersistence/nodes=40000/mode=checkpoint | B/op | 1.59708e+08 | 1.59707e+08 | 1.75683e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=40000/mode=restore-pending | ns/op | 1.1494e+10 | 1.07116e+10 | 1.37929e+10 | PASS |
| BenchmarkNativeActionPersistence/nodes=40000/mode=restore-pending | B/op | 1.26226e+09 | 1.26226e+09 | 1.38849e+09 | PASS |
| BenchmarkNativeActionPersistence/nodes=40000/mode=replay-pair | ns/op | 1.25147e+10 | 1.23184e+10 | 1.50177e+10 | PASS |
| BenchmarkNativeActionPersistence/nodes=40000/mode=replay-pair | B/op | 1.36919e+09 | 1.39579e+09 | 1.50612e+09 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=false/journal=false | thought_p95_ms | 1.22195 | 0.8183 | 1.50524 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=false/journal=false | B/op | 29020.5 | 28998 | 34567.5 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=false/journal=true | thought_p95_ms | 0.972 | 0.9612 | 1.2178 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=false/journal=true | B/op | 30730.5 | 30807 | 36363 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=true/journal=false | thought_p95_ms | 11.1715 | 10.41 | 12.9472 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=true/journal=false | B/op | 1.68329e+06 | 1.68333e+06 | 1.77155e+06 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=true/journal=true | thought_p95_ms | 10.3335 | 11.62 | 11.9835 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=true/journal=true | B/op | 1.68519e+06 | 1.68511e+06 | 1.77355e+06 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=false/journal=false | thought_p95_ms | 2.6285 | 2.732 | 3.12277 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=false/journal=false | B/op | 29026 | 29001 | 34573.3 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=false/journal=true | thought_p95_ms | 2.79 | 2.822 | 3.3085 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=false/journal=true | B/op | 30714.5 | 30773 | 36346.2 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=true/journal=false | thought_p95_ms | 44.755 | 69.68 | 51.5682 | FAIL |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=true/journal=false | B/op | 6.74448e+06 | 6.745e+06 | 7.0858e+06 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=true/journal=true | thought_p95_ms | 56.96 | 39.09 | 65.604 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=true/journal=true | B/op | 6.74592e+06 | 6.74636e+06 | 7.08732e+06 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=false/journal=false | thought_p95_ms | 21.695 | 25.99 | 25.0493 | FAIL |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=false/journal=false | B/op | 28968.5 | 29036 | 34512.9 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=false/journal=true | thought_p95_ms | 22.475 | 19.26 | 25.9463 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=false/journal=true | B/op | 30696.5 | 30744 | 36327.3 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=true/journal=false | thought_p95_ms | 481.7 | 420.5 | 554.055 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=true/journal=false | B/op | 5.55567e+07 | 5.55562e+07 | 5.83386e+07 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=true/journal=true | thought_p95_ms | 514.9 | 416.9 | 592.235 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=true/journal=true | B/op | 5.55582e+07 | 5.55579e+07 | 5.83402e+07 | PASS |
| BenchmarkGateGContextContinuityNativeIdle/nodes=40000/dense=false/journal=true | thought_p95_ms | 50.37 | 37.44 | 58.0255 | PASS |
| BenchmarkGateGContextContinuityNativeIdle/nodes=40000/dense=false/journal=true | B/op | 561854 | 561665 | 594043 | PASS |
| BenchmarkGateGAdmission | admission_p95_ms | nan | 6.1e-05 | 0.01 | PASS |
| BenchmarkGateGAdmission | B/op | nan | 0 | 512 | PASS |

## Descriptive resources

| Revision | Workload | p50 ms | p95 ms | p99 ms | B/op | allocs/op | Peak RSS MB | GC count/cell | GC pause ms/cell |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | BenchmarkGateGThought/nodes=1000/dense=false/journal=false | 0.4022 | 1.22195 | 1.9525 | 29020.5 | 334.5 | 23.425 | 2 | 0.34255 |
| baseline | BenchmarkGateGThought/nodes=1000/dense=false/journal=true | 0.39635 | 0.972 | 1.797 | 30730.5 | 344.5 | 23.425 | 2 | 0.10441 |
| baseline | BenchmarkGateGThought/nodes=1000/dense=true/journal=false | 6.831 | 11.1715 | 16.5 | 1.68329e+06 | 10527 | 25.99 | 53 | 2.892 |
| baseline | BenchmarkGateGThought/nodes=1000/dense=true/journal=true | 6.9475 | 10.3335 | 13.2295 | 1.68519e+06 | 10538.5 | 28.45 | 49.5 | 2.275 |
| baseline | BenchmarkGateGThought/nodes=4000/dense=false/journal=false | 1.381 | 2.6285 | 4.441 | 29026 | 335 | 48.335 | 1 | 0.027915 |
| baseline | BenchmarkGateGThought/nodes=4000/dense=false/journal=true | 1.397 | 2.79 | 11.018 | 30714.5 | 344 | 51.75 | 0.5 | 0.0571 |
| baseline | BenchmarkGateGThought/nodes=4000/dense=true/journal=false | 30.72 | 44.755 | 81.17 | 6.74448e+06 | 41027.5 | 53.46 | 126.5 | 6.5585 |
| baseline | BenchmarkGateGThought/nodes=4000/dense=true/journal=true | 32.66 | 56.96 | 70.88 | 6.74592e+06 | 41035.5 | 53.88 | 131.5 | 6.132 |
| baseline | BenchmarkGateGThought/nodes=40000/dense=false/journal=false | 15.955 | 21.695 | 28.25 | 28968.5 | 334 | 333.85 | 0 | 0 |
| baseline | BenchmarkGateGThought/nodes=40000/dense=false/journal=true | 15.24 | 22.475 | 24.15 | 30696.5 | 343.5 | 333.85 | 0 | 0 |
| baseline | BenchmarkGateGThought/nodes=40000/dense=true/journal=false | 339.6 | 481.7 | 565.05 | 5.55567e+07 | 405576 | 340.45 | 141 | 7.6905 |
| baseline | BenchmarkGateGThought/nodes=40000/dense=true/journal=true | 346.8 | 514.9 | 567.95 | 5.55582e+07 | 405585 | 340.45 | 147.5 | 8.6755 |
| baseline | BenchmarkGateGContextContinuity/nodes=40000/dense=false/journal=true | 27.555 | 50.37 | 69.63 | 561854 | 4530.5 | 298.1 | 2 | 0.07833 |
| baseline | BenchmarkGateGNativeStages/nodes=1000/dense=false | 0.38005 | 0.7116 | 0.8298 | 91859.5 | 1205.5 | 23.98 | 0.5 | 0.017205 |
| baseline | BenchmarkGateGNativeStages/nodes=1000/dense=true | 23.27 | 29.825 | 49.59 | 3.56077e+06 | 67128 | 23.98 | 18.5 | 0.827 |
| baseline | BenchmarkGateGNativeStages/nodes=4000/dense=false | 0.3698 | 0.68465 | 0.79045 | 91936.5 | 1208 | 50.515 | 0 | 0 |
| baseline | BenchmarkGateGNativeStages/nodes=4000/dense=true | 108.15 | 138.3 | 155 | 1.42159e+07 | 271702 | 51.045 | 30 | 1.0606 |
| baseline | BenchmarkGateGNativeStages/nodes=40000/dense=false | 0.4627 | 1.20195 | 1.417 | 91962.5 | 1204.5 | 329 | 0 | 0 |
| baseline | BenchmarkGateGNativeStages/nodes=40000/dense=true | 1282.5 | 1681 | 1797 | 1.25626e+08 | 2.72475e+06 | 329 | 31.5 | 1.8055 |
| baseline | BenchmarkGateGJournalAppend | 0.004251 | 0.012685 | 0.08204 | 1811 | 11 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=1000/mode=checkpoint | — | — | — | 4.36763e+06 | 32503.5 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=1000/mode=restore-pending | — | — | — | 2.62048e+07 | 53183.5 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=1000/mode=replay-pair | — | — | — | 3.05103e+07 | 58560 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=4000/mode=checkpoint | — | — | — | 1.63199e+07 | 122504 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=4000/mode=restore-pending | — | — | — | 1.29941e+08 | 200684 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=4000/mode=replay-pair | — | — | — | 1.42513e+08 | 206072 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=40000/mode=checkpoint | — | — | — | 1.59708e+08 | 1.20251e+06 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=40000/mode=restore-pending | — | — | — | 1.26226e+09 | 1.96956e+06 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=40000/mode=replay-pair | — | — | — | 1.36919e+09 | 1.97491e+06 | — | — | — |
| candidate | BenchmarkGateGThought/nodes=1000/dense=false/journal=false | 0.4379 | 1.0793 | 1.4245 | 29002 | 334.5 | 23.815 | 2 | 0.05104 |
| candidate | BenchmarkGateGThought/nodes=1000/dense=false/journal=true | 0.4568 | 1.4815 | 4.325 | 30726.5 | 344.5 | 23.815 | 2 | 0.29396 |
| candidate | BenchmarkGateGThought/nodes=1000/dense=true/journal=false | 7.6905 | 12.21 | 16.315 | 1.68342e+06 | 10528.5 | 25.405 | 64 | 3.5805 |
| candidate | BenchmarkGateGThought/nodes=1000/dense=true/journal=true | 7.661 | 12.835 | 19.285 | 1.68511e+06 | 10538.5 | 25.735 | 65 | 2.9755 |
| candidate | BenchmarkGateGThought/nodes=4000/dense=false/journal=false | 1.219 | 2.299 | 2.6695 | 28963 | 333.5 | 50.17 | 0 | 0 |
| candidate | BenchmarkGateGThought/nodes=4000/dense=false/journal=true | 1.182 | 1.7625 | 2.195 | 30717.5 | 344.5 | 51.41 | 0.5 | 0.01476 |
| candidate | BenchmarkGateGThought/nodes=4000/dense=true/journal=false | 31.18 | 47.085 | 58.335 | 6.74486e+06 | 41030.5 | 52.145 | 127 | 12.29 |
| candidate | BenchmarkGateGThought/nodes=4000/dense=true/journal=true | 32.725 | 92.915 | 152.68 | 6.7465e+06 | 41039.5 | 53.655 | 133.5 | 7.0165 |
| candidate | BenchmarkGateGThought/nodes=40000/dense=false/journal=false | 17.74 | 27.71 | 31.09 | 28998.5 | 334.5 | 327.1 | 0.5 | 0.01626 |
| candidate | BenchmarkGateGThought/nodes=40000/dense=false/journal=true | 16.805 | 26.24 | 34.26 | 30752 | 345 | 327.1 | 0 | 0 |
| candidate | BenchmarkGateGThought/nodes=40000/dense=true/journal=false | 350 | 491.55 | 714.6 | 5.55565e+07 | 405576 | 333.95 | 143 | 8.4725 |
| candidate | BenchmarkGateGThought/nodes=40000/dense=true/journal=true | 359.1 | 568.3 | 659.35 | 5.55576e+07 | 405580 | 359 | 147.5 | 10.007 |
| candidate | BenchmarkGateGContextContinuity/nodes=40000/dense=false/journal=true | 20.435 | 31.545 | 51.095 | 561780 | 4529.5 | 302.3 | 2 | 0.096305 |
| candidate | BenchmarkGateGNativeStages/nodes=1000/dense=false | 0.34075 | 0.7739 | 1.36445 | 91110 | 1218 | 24.855 | 0 | 0 |
| candidate | BenchmarkGateGNativeStages/nodes=1000/dense=true | 22.975 | 35.38 | 39.71 | 3.63368e+06 | 70020 | 24.855 | 19.5 | 0.8037 |
| candidate | BenchmarkGateGNativeStages/nodes=4000/dense=false | 0.34745 | 1.15705 | 1.69745 | 91049.5 | 1216.5 | 47.4 | 0 | 0 |
| candidate | BenchmarkGateGNativeStages/nodes=4000/dense=true | 102.975 | 151.85 | 209.6 | 1.45226e+07 | 283594 | 47.4 | 29.5 | 1.3325 |
| candidate | BenchmarkGateGNativeStages/nodes=40000/dense=false | 0.40445 | 0.9848 | 1.6935 | 91250 | 1218.5 | 332.45 | 0 | 0 |
| candidate | BenchmarkGateGNativeStages/nodes=40000/dense=true | 1373 | 1636.5 | 1696.5 | 1.28666e+08 | 2.84466e+06 | 344.05 | 33 | 1.9685 |
| candidate | BenchmarkGateGJournalAppend | 0.004251 | 0.010695 | 0.020945 | 1811 | 11 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=1000/mode=checkpoint | — | — | — | 4.3673e+06 | 32500 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=1000/mode=restore-pending | — | — | — | 2.62053e+07 | 53183.5 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=1000/mode=replay-pair | — | — | — | 2.95007e+07 | 58698.5 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=4000/mode=checkpoint | — | — | — | 1.63184e+07 | 122501 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=4000/mode=restore-pending | — | — | — | 1.33931e+08 | 200680 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=4000/mode=replay-pair | — | — | — | 1.38528e+08 | 206208 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=40000/mode=checkpoint | — | — | — | 1.59707e+08 | 1.20251e+06 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=40000/mode=restore-pending | — | — | — | 1.26226e+09 | 1.96956e+06 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=40000/mode=replay-pair | — | — | — | 1.39579e+09 | 1.97505e+06 | — | — | — |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=false/journal=false | 0.4062 | 0.8183 | 1.293 | 28998 | 334 | 23.61 | 1 | 0.04148 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=false/journal=true | 0.476 | 0.9612 | 1.273 | 30807 | 345 | 23.61 | 2 | 0.05842 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=true/journal=false | 7.291 | 10.41 | 24.85 | 1.68333e+06 | 10529 | 23.61 | 77 | 3.976 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=true/journal=true | 7.239 | 11.62 | 17.74 | 1.68511e+06 | 10539 | 23.61 | 78 | 4.541 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=false/journal=false | 1.372 | 2.732 | 4.242 | 29001 | 335 | 46.67 | 1 | 0.02639 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=false/journal=true | 1.46 | 2.822 | 3.426 | 30773 | 345 | 47.88 | 1 | 0.02979 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=true/journal=false | 31.13 | 69.68 | 120.7 | 6.745e+06 | 41031 | 52 | 131 | 8.161 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=true/journal=true | 27.87 | 39.09 | 62.32 | 6.74636e+06 | 41039 | 55.7 | 130 | 5.643 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=false/journal=false | 17.31 | 25.99 | 31.06 | 29036 | 335 | 292.4 | 1 | 0.03043 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=false/journal=true | 15.66 | 19.26 | 20.64 | 30744 | 344 | 309.5 | 0 | 0 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=true/journal=false | 341.2 | 420.5 | 563.4 | 5.55562e+07 | 405574 | 309.7 | 143 | 7.099 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=true/journal=true | 336.9 | 416.9 | 500.8 | 5.55579e+07 | 405582 | 310.3 | 146 | 7.939 |
| candidate-only | BenchmarkGateGContextContinuityNativeIdle/nodes=40000/dense=false/journal=true | 20.19 | 37.44 | 55.81 | 561665 | 4529 | 334.4 | 2 | 0.06956 |
| candidate-only | BenchmarkGateGAdmission | 6e-05 | 6.1e-05 | 6.5e-05 | 0 | 0 | — | — | — |
| candidate-only | BenchmarkGateGMixedHandoff/nodes=1000 | 0.7369 | 6.108 | 36.84 | 81397 | 918 | 24.44 | 2 | 1.285 |
| candidate-only | BenchmarkGateGMixedHandoff/nodes=4000 | 1.389 | 2.746 | 6.054 | 82559 | 917 | 48.35 | 2 | 0.1402 |
| candidate-only | BenchmarkGateGMixedHandoff/nodes=40000 | 20.2 | 41.7 | 66.21 | 97614 | 917 | 296.8 | 0 | 0 |

## Interpretation limits

- Means of per-run percentiles are compared; observations are not pooled.
- Native stage tails use 20 pairs/run and are descriptive.
- Persistence uses three operations/run and reports means, not p95/p99.
- RSS is cumulative process peak; GC statistics also include untimed seeding.
- No baseline latency exists for mixed handoff: baseline rejects it.
- This statistical resource check alone cannot certify the other Gate G requirements.
