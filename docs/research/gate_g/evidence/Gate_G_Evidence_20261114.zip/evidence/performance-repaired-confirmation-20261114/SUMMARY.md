# Gate G performance confirmation

Complete: **True**. Passed locked observed comparisons: **False** (81/90).

Values are means of per-run measurements. Raw samples/runs and every failed comparison remain in summary.json and the original logs.

| Workload | Metric | Baseline | Candidate | Limit | Result |
|---|---|---:|---:|---:|---|
| BenchmarkGateGThought/nodes=1000/dense=false/journal=false | thought_p95_ms | 0.78345 | 1.1645 | 1.00097 | FAIL |
| BenchmarkGateGThought/nodes=1000/dense=false/journal=false | B/op | 29025.5 | 26920 | 34572.8 | PASS |
| BenchmarkGateGThought/nodes=1000/dense=false/journal=true | thought_p95_ms | 0.7431 | 0.99925 | 0.954565 | FAIL |
| BenchmarkGateGThought/nodes=1000/dense=false/journal=true | B/op | 30776 | 28699.5 | 36410.8 | PASS |
| BenchmarkGateGThought/nodes=1000/dense=true/journal=false | thought_p95_ms | 9.9525 | 12.62 | 11.5454 | FAIL |
| BenchmarkGateGThought/nodes=1000/dense=true/journal=false | B/op | 1.68331e+06 | 1.57119e+06 | 1.77157e+06 | PASS |
| BenchmarkGateGThought/nodes=1000/dense=true/journal=true | thought_p95_ms | 10.198 | 10.7015 | 11.8277 | PASS |
| BenchmarkGateGThought/nodes=1000/dense=true/journal=true | B/op | 1.68494e+06 | 1.57299e+06 | 1.77328e+06 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=false/journal=false | thought_p95_ms | 3.265 | 1.8685 | 3.85475 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=false/journal=false | B/op | 29027.5 | 26938 | 34574.9 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=false/journal=true | thought_p95_ms | 2.8285 | 1.6645 | 3.35277 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=false/journal=true | B/op | 30773.5 | 28655 | 36408.2 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=true/journal=false | thought_p95_ms | 35.03 | 30.265 | 40.3845 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=true/journal=false | B/op | 6.74452e+06 | 6.29653e+06 | 7.08584e+06 | PASS |
| BenchmarkGateGThought/nodes=4000/dense=true/journal=true | thought_p95_ms | 35.08 | 41.76 | 40.442 | FAIL |
| BenchmarkGateGThought/nodes=4000/dense=true/journal=true | B/op | 6.74662e+06 | 6.29804e+06 | 7.08804e+06 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=false/journal=false | thought_p95_ms | 16.915 | 12.645 | 19.5522 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=false/journal=false | B/op | 28987.5 | 26934.5 | 34532.9 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=false/journal=true | thought_p95_ms | 18.115 | 13.245 | 20.9323 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=false/journal=true | B/op | 30778 | 28642 | 36412.9 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=true/journal=false | thought_p95_ms | 401.8 | 421.25 | 462.17 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=true/journal=false | B/op | 5.55555e+07 | 5.1076e+07 | 5.83374e+07 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=true/journal=true | thought_p95_ms | 590.25 | 499.85 | 678.887 | PASS |
| BenchmarkGateGThought/nodes=40000/dense=true/journal=true | B/op | 5.55582e+07 | 5.10774e+07 | 5.83402e+07 | PASS |
| BenchmarkGateGContextContinuity/nodes=40000/dense=false/journal=true | thought_p95_ms | 236.685 | 24.87 | 272.288 | PASS |
| BenchmarkGateGContextContinuity/nodes=40000/dense=false/journal=true | B/op | 561830 | 515529 | 594018 | PASS |
| BenchmarkGateGNativeStages/nodes=1000/dense=false | operation_p95_ms | 0.18031 | 0.110205 | 0.316372 | PASS |
| BenchmarkGateGNativeStages/nodes=1000/dense=false | learning_p95_ms | 0.07461 | 0.045075 | 0.189532 | PASS |
| BenchmarkGateGNativeStages/nodes=1000/dense=false | B/op | 91952 | 90517 | 105243 | PASS |
| BenchmarkGateGNativeStages/nodes=1000/dense=true | operation_p95_ms | 7.6285 | 8.45 | 9.2542 | PASS |
| BenchmarkGateGNativeStages/nodes=1000/dense=true | learning_p95_ms | 2.6225 | 1.9585 | 3.247 | PASS |
| BenchmarkGateGNativeStages/nodes=1000/dense=true | B/op | 3.55688e+06 | 3.57772e+06 | 3.91667e+06 | PASS |
| BenchmarkGateGNativeStages/nodes=4000/dense=false | operation_p95_ms | 0.20205 | 0.25105 | 0.34246 | PASS |
| BenchmarkGateGNativeStages/nodes=4000/dense=false | learning_p95_ms | 0.094475 | 0.2182 | 0.21337 | FAIL |
| BenchmarkGateGNativeStages/nodes=4000/dense=false | B/op | 91990.5 | 90472 | 105286 | PASS |
| BenchmarkGateGNativeStages/nodes=4000/dense=true | operation_p95_ms | 34.685 | 27.41 | 41.722 | PASS |
| BenchmarkGateGNativeStages/nodes=4000/dense=true | learning_p95_ms | 10.0575 | 12.3135 | 12.169 | FAIL |
| BenchmarkGateGNativeStages/nodes=4000/dense=true | B/op | 1.42159e+07 | 1.42989e+07 | 1.56415e+07 | PASS |
| BenchmarkGateGNativeStages/nodes=40000/dense=false | operation_p95_ms | 0.1719 | 0.11205 | 0.30628 | PASS |
| BenchmarkGateGNativeStages/nodes=40000/dense=false | learning_p95_ms | 0.0702 | 0.07081 | 0.18424 | PASS |
| BenchmarkGateGNativeStages/nodes=40000/dense=false | B/op | 91940.5 | 90508.5 | 105231 | PASS |
| BenchmarkGateGNativeStages/nodes=40000/dense=true | operation_p95_ms | 379.25 | 354.25 | 455.2 | PASS |
| BenchmarkGateGNativeStages/nodes=40000/dense=true | learning_p95_ms | 116.05 | 119.15 | 139.36 | PASS |
| BenchmarkGateGNativeStages/nodes=40000/dense=true | B/op | 1.25631e+08 | 1.26426e+08 | 1.38198e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=1000/mode=checkpoint | ns/op | 2.01149e+07 | 1.96623e+07 | 2.42379e+07 | PASS |
| BenchmarkNativeActionPersistence/nodes=1000/mode=checkpoint | B/op | 4.3675e+06 | 4.36744e+06 | 4.80835e+06 | PASS |
| BenchmarkNativeActionPersistence/nodes=1000/mode=restore-pending | ns/op | 2.80303e+08 | 2.72701e+08 | 3.36464e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=1000/mode=restore-pending | B/op | 2.65438e+07 | 2.65431e+07 | 2.92022e+07 | PASS |
| BenchmarkNativeActionPersistence/nodes=1000/mode=replay-pair | ns/op | 2.795e+08 | 2.79359e+08 | 3.35501e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=1000/mode=replay-pair | B/op | 3.08486e+07 | 3.01802e+07 | 3.39376e+07 | PASS |
| BenchmarkNativeActionPersistence/nodes=4000/mode=checkpoint | ns/op | 6.62995e+07 | 9.83243e+07 | 7.96594e+07 | FAIL |
| BenchmarkNativeActionPersistence/nodes=4000/mode=checkpoint | B/op | 1.63197e+07 | 1.63199e+07 | 1.79558e+07 | PASS |
| BenchmarkNativeActionPersistence/nodes=4000/mode=restore-pending | ns/op | 1.00248e+09 | 1.05431e+09 | 1.20307e+09 | PASS |
| BenchmarkNativeActionPersistence/nodes=4000/mode=restore-pending | B/op | 1.37921e+08 | 1.37922e+08 | 1.51717e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=4000/mode=replay-pair | ns/op | 1.16188e+09 | 1.17265e+09 | 1.39436e+09 | PASS |
| BenchmarkNativeActionPersistence/nodes=4000/mode=replay-pair | B/op | 1.46506e+08 | 1.42521e+08 | 1.61161e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=40000/mode=checkpoint | ns/op | 8.28993e+08 | 9.49688e+08 | 9.94892e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=40000/mode=checkpoint | B/op | 1.59707e+08 | 1.59707e+08 | 1.75682e+08 | PASS |
| BenchmarkNativeActionPersistence/nodes=40000/mode=restore-pending | ns/op | 1.3196e+10 | 1.13351e+10 | 1.58353e+10 | PASS |
| BenchmarkNativeActionPersistence/nodes=40000/mode=restore-pending | B/op | 1.26226e+09 | 1.26226e+09 | 1.38849e+09 | PASS |
| BenchmarkNativeActionPersistence/nodes=40000/mode=replay-pair | ns/op | 1.20249e+10 | 1.21345e+10 | 1.443e+10 | PASS |
| BenchmarkNativeActionPersistence/nodes=40000/mode=replay-pair | B/op | 1.36919e+09 | 1.39578e+09 | 1.50612e+09 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=false/journal=false | thought_p95_ms | 0.78345 | 0.7017 | 1.00097 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=false/journal=false | B/op | 29025.5 | 26885 | 34572.8 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=false/journal=true | thought_p95_ms | 0.7431 | 0.7019 | 0.954565 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=false/journal=true | B/op | 30776 | 28666 | 36410.8 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=true/journal=false | thought_p95_ms | 9.9525 | 9.663 | 11.5454 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=true/journal=false | B/op | 1.68331e+06 | 1.57105e+06 | 1.77157e+06 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=true/journal=true | thought_p95_ms | 10.198 | 11.38 | 11.8277 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=true/journal=true | B/op | 1.68494e+06 | 1.57324e+06 | 1.77328e+06 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=false/journal=false | thought_p95_ms | 3.265 | 2.505 | 3.85475 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=false/journal=false | B/op | 29027.5 | 26950 | 34574.9 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=false/journal=true | thought_p95_ms | 2.8285 | 3.174 | 3.35277 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=false/journal=true | B/op | 30773.5 | 28720 | 36408.2 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=true/journal=false | thought_p95_ms | 35.03 | 32.32 | 40.3845 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=true/journal=false | B/op | 6.74452e+06 | 6.29593e+06 | 7.08584e+06 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=true/journal=true | thought_p95_ms | 35.08 | 42.26 | 40.442 | FAIL |
| BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=true/journal=true | B/op | 6.74662e+06 | 6.29779e+06 | 7.08804e+06 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=false/journal=false | thought_p95_ms | 16.915 | 20.78 | 19.5522 | FAIL |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=false/journal=false | B/op | 28987.5 | 26914 | 34532.9 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=false/journal=true | thought_p95_ms | 18.115 | 17.21 | 20.9323 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=false/journal=true | B/op | 30778 | 28717 | 36412.9 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=true/journal=false | thought_p95_ms | 401.8 | 361.3 | 462.17 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=true/journal=false | B/op | 5.55555e+07 | 5.10766e+07 | 5.83374e+07 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=true/journal=true | thought_p95_ms | 590.25 | 321.1 | 678.887 | PASS |
| BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=true/journal=true | B/op | 5.55582e+07 | 5.10778e+07 | 5.83402e+07 | PASS |
| BenchmarkGateGContextContinuityNativeIdle/nodes=40000/dense=false/journal=true | thought_p95_ms | 236.685 | 17.6 | 272.288 | PASS |
| BenchmarkGateGContextContinuityNativeIdle/nodes=40000/dense=false/journal=true | B/op | 561830 | 515718 | 594018 | PASS |
| BenchmarkGateGAdmission | admission_p95_ms | nan | 6e-05 | 0.01 | PASS |
| BenchmarkGateGAdmission | B/op | nan | 0 | 512 | PASS |

## Descriptive resources

| Revision | Workload | p50 ms | p95 ms | p99 ms | B/op | allocs/op | Peak RSS MB | GC count/cell | GC pause ms/cell |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | BenchmarkGateGThought/nodes=1000/dense=false/journal=false | 0.33275 | 0.78345 | 1.203 | 29025.5 | 334.5 | 24.075 | 2 | 0.02779 |
| baseline | BenchmarkGateGThought/nodes=1000/dense=false/journal=true | 0.36315 | 0.7431 | 0.97445 | 30776 | 345.5 | 24.075 | 2 | 0.02698 |
| baseline | BenchmarkGateGThought/nodes=1000/dense=true/journal=false | 5.974 | 9.9525 | 14.36 | 1.68331e+06 | 10527 | 25.695 | 54 | 1.1515 |
| baseline | BenchmarkGateGThought/nodes=1000/dense=true/journal=true | 6.5425 | 10.198 | 15.8 | 1.68494e+06 | 10537 | 27.26 | 51 | 1.98925 |
| baseline | BenchmarkGateGThought/nodes=4000/dense=false/journal=false | 1.331 | 3.265 | 5.2455 | 29027.5 | 335 | 49.87 | 1 | 0.02102 |
| baseline | BenchmarkGateGThought/nodes=4000/dense=false/journal=true | 1.303 | 2.8285 | 5.47 | 30773.5 | 345.5 | 49.87 | 1 | 0.019715 |
| baseline | BenchmarkGateGThought/nodes=4000/dense=true/journal=false | 26.49 | 35.03 | 48.09 | 6.74452e+06 | 41027.5 | 51.02 | 129.5 | 3.177 |
| baseline | BenchmarkGateGThought/nodes=4000/dense=true/journal=true | 26.07 | 35.08 | 55.335 | 6.74662e+06 | 41040.5 | 51.31 | 137 | 2.793 |
| baseline | BenchmarkGateGThought/nodes=40000/dense=false/journal=false | 11.135 | 16.915 | 27.54 | 28987.5 | 334 | 333.6 | 0 | 0 |
| baseline | BenchmarkGateGThought/nodes=40000/dense=false/journal=true | 11.315 | 18.115 | 37.67 | 30778 | 345 | 333.6 | 0 | 0 |
| baseline | BenchmarkGateGThought/nodes=40000/dense=true/journal=false | 308.95 | 401.8 | 1906.2 | 5.55555e+07 | 405569 | 339.4 | 142.5 | 7.0175 |
| baseline | BenchmarkGateGThought/nodes=40000/dense=true/journal=true | 325.3 | 590.25 | 883.75 | 5.55582e+07 | 405585 | 339.4 | 147.5 | 7.514 |
| baseline | BenchmarkGateGContextContinuity/nodes=40000/dense=false/journal=true | 14.25 | 236.685 | 829.73 | 561830 | 4529 | 302.2 | 2 | 0.11942 |
| baseline | BenchmarkGateGNativeStages/nodes=1000/dense=false | 0.3886 | 0.9486 | 1.2532 | 91952 | 1207.5 | 23.87 | 0.5 | 0.007645 |
| baseline | BenchmarkGateGNativeStages/nodes=1000/dense=true | 23.415 | 30.19 | 33.64 | 3.55688e+06 | 67119 | 23.87 | 14.5 | 0.23195 |
| baseline | BenchmarkGateGNativeStages/nodes=4000/dense=false | 0.4571 | 0.6456 | 0.7891 | 91990.5 | 1208 | 46.44 | 0 | 0 |
| baseline | BenchmarkGateGNativeStages/nodes=4000/dense=true | 98.775 | 412.7 | 445.2 | 1.42159e+07 | 271702 | 52.7 | 30 | 5.822 |
| baseline | BenchmarkGateGNativeStages/nodes=40000/dense=false | 0.488 | 0.83985 | 0.97115 | 91940.5 | 1205.5 | 333 | 0 | 0 |
| baseline | BenchmarkGateGNativeStages/nodes=40000/dense=true | 1136.5 | 1302.5 | 1355 | 1.25631e+08 | 2.72479e+06 | 337.3 | 32 | 2.0605 |
| baseline | BenchmarkGateGJournalAppend | 0.0041255 | 0.0105435 | 0.03398 | 1811 | 11 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=1000/mode=checkpoint | — | — | — | 4.3675e+06 | 32504 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=1000/mode=restore-pending | — | — | — | 2.65438e+07 | 53193.5 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=1000/mode=replay-pair | — | — | — | 3.08486e+07 | 58549 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=4000/mode=checkpoint | — | — | — | 1.63197e+07 | 122502 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=4000/mode=restore-pending | — | — | — | 1.37921e+08 | 200680 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=4000/mode=replay-pair | — | — | — | 1.46506e+08 | 206066 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=40000/mode=checkpoint | — | — | — | 1.59707e+08 | 1.20251e+06 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=40000/mode=restore-pending | — | — | — | 1.26226e+09 | 1.96955e+06 | — | — | — |
| baseline | BenchmarkNativeActionPersistence/nodes=40000/mode=replay-pair | — | — | — | 1.36919e+09 | 1.97491e+06 | — | — | — |
| candidate | BenchmarkGateGThought/nodes=1000/dense=false/journal=false | 0.43595 | 1.1645 | 2.31 | 26920 | 260.5 | 23.96 | 2 | 0.032725 |
| candidate | BenchmarkGateGThought/nodes=1000/dense=false/journal=true | 0.37395 | 0.99925 | 2.6655 | 28699.5 | 271 | 23.96 | 2 | 0.03149 |
| candidate | BenchmarkGateGThought/nodes=1000/dense=true/journal=false | 6.5935 | 12.62 | 19.195 | 1.57119e+06 | 6518 | 27.82 | 47.5 | 2.89185 |
| candidate | BenchmarkGateGThought/nodes=1000/dense=true/journal=true | 6.8115 | 10.7015 | 12.425 | 1.57299e+06 | 6528.5 | 27.82 | 71 | 1.677 |
| candidate | BenchmarkGateGThought/nodes=4000/dense=false/journal=false | 1.173 | 1.8685 | 2.406 | 26938 | 261 | 54.885 | 0.5 | 0.01198 |
| candidate | BenchmarkGateGThought/nodes=4000/dense=false/journal=true | 1.197 | 1.6645 | 2.2545 | 28655 | 270.5 | 54.885 | 0 | 0 |
| candidate | BenchmarkGateGThought/nodes=4000/dense=true/journal=false | 22.705 | 30.265 | 51.225 | 6.29653e+06 | 25019 | 55.235 | 99.5 | 2.7495 |
| candidate | BenchmarkGateGThought/nodes=4000/dense=true/journal=true | 25.605 | 41.76 | 85.91 | 6.29804e+06 | 25028 | 55.565 | 125 | 5.1695 |
| candidate | BenchmarkGateGThought/nodes=40000/dense=false/journal=false | 10.114 | 12.645 | 14.32 | 26934.5 | 260.5 | 334.4 | 0 | 0 |
| candidate | BenchmarkGateGThought/nodes=40000/dense=false/journal=true | 10.345 | 13.245 | 18.835 | 28642 | 270.5 | 334.4 | 0.5 | 0.009985 |
| candidate | BenchmarkGateGThought/nodes=40000/dense=true/journal=false | 275.7 | 421.25 | 853.7 | 5.1076e+07 | 245565 | 342.05 | 132.5 | 6.0875 |
| candidate | BenchmarkGateGThought/nodes=40000/dense=true/journal=true | 296.4 | 499.85 | 614.4 | 5.10774e+07 | 245572 | 343.55 | 136 | 6.251 |
| candidate | BenchmarkGateGContextContinuity/nodes=40000/dense=false/journal=true | 14.235 | 24.87 | 34.88 | 515529 | 2877.5 | 302.25 | 2 | 0.05833 |
| candidate | BenchmarkGateGNativeStages/nodes=1000/dense=false | 0.33325 | 0.4821 | 0.51455 | 90517 | 1197 | 24.115 | 0 | 0 |
| candidate | BenchmarkGateGNativeStages/nodes=1000/dense=true | 23.995 | 31.7 | 72.33 | 3.57772e+06 | 68015 | 24.115 | 17.5 | 0.40245 |
| candidate | BenchmarkGateGNativeStages/nodes=4000/dense=false | 0.6401 | 1.43545 | 3.6915 | 90472 | 1195.5 | 47.955 | 0 | 0 |
| candidate | BenchmarkGateGNativeStages/nodes=4000/dense=true | 99.155 | 142.85 | 167.85 | 1.42989e+07 | 275594 | 51.025 | 31 | 2.1345 |
| candidate | BenchmarkGateGNativeStages/nodes=40000/dense=false | 0.34295 | 0.5409 | 0.5554 | 90508.5 | 1194.5 | 333.2 | 0 | 0 |
| candidate | BenchmarkGateGNativeStages/nodes=40000/dense=true | 1153 | 1385 | 1715 | 1.26426e+08 | 2.76466e+06 | 334.75 | 33.5 | 1.3725 |
| candidate | BenchmarkGateGJournalAppend | 0.004347 | 0.01467 | 0.147925 | 1811 | 11 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=1000/mode=checkpoint | — | — | — | 4.36744e+06 | 32503 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=1000/mode=restore-pending | — | — | — | 2.65431e+07 | 53198.5 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=1000/mode=replay-pair | — | — | — | 3.01802e+07 | 58720 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=4000/mode=checkpoint | — | — | — | 1.63199e+07 | 122504 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=4000/mode=restore-pending | — | — | — | 1.37922e+08 | 200692 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=4000/mode=replay-pair | — | — | — | 1.42521e+08 | 206210 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=40000/mode=checkpoint | — | — | — | 1.59707e+08 | 1.20251e+06 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=40000/mode=restore-pending | — | — | — | 1.26226e+09 | 1.96952e+06 | — | — | — |
| candidate | BenchmarkNativeActionPersistence/nodes=40000/mode=replay-pair | — | — | — | 1.39578e+09 | 1.97503e+06 | — | — | — |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=false/journal=false | 0.3226 | 0.7017 | 0.8265 | 26885 | 260 | 24.63 | 1 | 0.02058 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=false/journal=true | 0.3304 | 0.7019 | 1.008 | 28666 | 271 | 24.63 | 2 | 0.02785 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=true/journal=false | 5.969 | 9.663 | 13.44 | 1.57105e+06 | 6517 | 27.94 | 48 | 0.9096 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=1000/dense=true/journal=true | 6.549 | 11.38 | 16.56 | 1.57324e+06 | 6531 | 27.94 | 70 | 3.252 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=false/journal=false | 1.217 | 2.505 | 3.892 | 26950 | 261 | 45.23 | 1 | 0.02103 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=false/journal=true | 1.284 | 3.174 | 10.84 | 28720 | 271 | 45.72 | 1 | 0.01711 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=true/journal=false | 23.7 | 32.32 | 36.34 | 6.29593e+06 | 25017 | 53.26 | 122 | 5.793 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=4000/dense=true/journal=true | 26.7 | 42.26 | 79.07 | 6.29779e+06 | 25026 | 53.26 | 133 | 3.652 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=false/journal=false | 11.18 | 20.78 | 40.6 | 26914 | 261 | 334.5 | 0 | 0 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=false/journal=true | 11.53 | 17.21 | 33.75 | 28717 | 271 | 334.5 | 1 | 0.0185 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=true/journal=false | 283.6 | 361.3 | 408.8 | 5.10766e+07 | 245568 | 334.5 | 133 | 5.366 |
| candidate-only | BenchmarkGateGThoughtNativeIdle/nodes=40000/dense=true/journal=true | 272.5 | 321.1 | 346.3 | 5.10778e+07 | 245574 | 336 | 138 | 6.749 |
| candidate-only | BenchmarkGateGContextContinuityNativeIdle/nodes=40000/dense=false/journal=true | 12.06 | 17.6 | 30.52 | 515718 | 2879 | 304.4 | 2 | 0.05392 |
| candidate-only | BenchmarkGateGAdmission | 5.6e-05 | 6e-05 | 7.2e-05 | 0 | 0 | — | — | — |
| candidate-only | BenchmarkGateGMixedHandoff/nodes=1000 | 0.4612 | 0.998 | 1.906 | 80548 | 887 | 24.04 | 2 | 0.03005 |
| candidate-only | BenchmarkGateGMixedHandoff/nodes=4000 | 1.38 | 2.62 | 5.553 | 81813 | 889 | 43.57 | 2 | 0.03971 |
| candidate-only | BenchmarkGateGMixedHandoff/nodes=40000 | 13.97 | 17.24 | 25.92 | 96748 | 887 | 332.8 | 0 | 0 |

## Interpretation limits

- Means of per-run percentiles are compared; observations are not pooled.
- Native stage tails use 20 pairs/run and are descriptive.
- Persistence uses three operations/run and reports means, not p95/p99.
- RSS is cumulative process peak; GC statistics also include untimed seeding.
- No baseline latency exists for mixed handoff: baseline rejects it.
- This statistical resource check alone cannot certify the other Gate G requirements.
