package runtime

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"syscall"
	"time"

	"github.com/project-horizon/horizon-core/services/ai/knowledge"
	"github.com/project-horizon/horizon-core/services/ai/learning"
)

const EventLogSchemaVersion = 3

func supportedEventLogSchema(version int) bool {
	return version == nativeJournalSchemaVersion || version == coordinatedJournalSchemaVersion || version == terminalExposureJournalSchemaVersion || version == phase4JournalSchemaVersion || version == phase3JournalSchemaVersion || version == phase2JournalSchemaVersion || version == componentLearningJournalSchemaVersion || version == terminalReadoutJournalSchemaVersion || version == neuralMetaJournalSchemaVersion || version == cognitiveModelJournalSchemaVersion || version == 1 || version == 2 || version == EventLogSchemaVersion || version == compositionJournalSchemaVersion
}

type LoggedEvent struct {
	NativeControl             *NativeControlCommand          `json:"native_control,omitempty"`
	CognitiveModel            *CognitiveModelCommand         `json:"cognitive_model,omitempty"`
	CompositionPerception     *CompositionPerception         `json:"composition_perception,omitempty"`
	CompositionEncoding       string                         `json:"composition_encoding,omitempty"`
	CompositionMigration      *CompositionMigration          `json:"composition_migration,omitempty"`
	CompositionExposure       *knowledge.CompositionExposure `json:"composition_exposure,omitempty"`
	SpellingExposure          *knowledge.SpellingExposure    `json:"spelling_exposure,omitempty"`
	WrittenGroundingMigration *WrittenGroundingMigration     `json:"written_grounding_migration,omitempty"`
	DynamicsEncoding          knowledge.DynamicsEncoding     `json:"dynamics_encoding,omitempty"`
	SurfaceRebinding          *WrittenSurfaceRebinding       `json:"surface_rebinding,omitempty"`
	SurfaceEncoding           knowledge.SurfaceEncoding      `json:"surface_encoding,omitempty"`
	InquiryOutcome            *InquiryOutcomeCommand         `json:"inquiry_outcome,omitempty"`
	ObservationCommand        *ObservationCommand            `json:"observation_command,omitempty"`
	ActionBinding             *ActionBinding                 `json:"action_binding,omitempty"`
	SchemaVersion             int                            `json:"schema_version"`
	BrainIdentity             string                         `json:"brain_identity"`
	Sequence                  uint64                         `json:"sequence"`
	Type                      string                         `json:"type"`
	Timestamp                 time.Time                      `json:"timestamp"`
	Event                     *Event                         `json:"event,omitempty"`
	Experience                *learning.Experience           `json:"experience,omitempty"`
	KnowledgeDocument         *knowledge.KnowledgeDocument   `json:"knowledge_document,omitempty"`
	Vector                    *knowledge.NeuralVector        `json:"vector,omitempty"`
	Outcome                   *OutcomeEvent                  `json:"outcome,omitempty"`
	Consequence               *InquiryConsequenceEvent       `json:"consequence,omitempty"`
	IntentHash                string                         `json:"intent_hash,omitempty"`
}

const (
	EventTypeProcess          = "process"
	EventTypeObservation      = "observation"
	EventTypeCognitiveProcess = "cognitive_process"
	EventTypeCognitiveThink   = "cognitive_think"
	EventTypeActionBinding    = "action_binding"
	EventTypeInquiryOutcome   = "inquiry_outcome"
	EventTypeLearn            = "learn"
	EventTypeThink            = "think"
	EventTypeOutcome          = "outcome"
	EventTypeConsequence      = "consequence"
	EventTypeSensorIntent     = "sensor_intent"
	EventTypeSensorCommit     = "sensor_commit"
	// A document import is one durable revision, even if it performs multiple
	// ordered neural exposure updates in that same revision.
	EventTypeKnowledgeImport = "knowledge_import"
	EventTypeVectorGround    = "vector_ground"
)

type EventLog struct {
	mu       sync.Mutex
	file     *os.File
	lockFile *os.File
	// Also detect in-place truncation, which preserves the inode.
	acknowledgedSize int64
	// Test-only fault injection; guarded by mu like file writes.
	beforeAppend     func(LoggedEvent) error
	transactionFault func(string, LoggedEvent) // unexported test hook, under mu
}

func OpenEventLog(path string) (*EventLog, error) {
	if path == "" {
		return nil, errors.New("event log path is empty")
	}
	lockFile, err := os.OpenFile(path+".writer.lock", os.O_CREATE|os.O_RDWR, 0600)
	if err != nil {
		return nil, fmt.Errorf("open event log writer lock: %w", err)
	}
	if err := syscall.Flock(int(lockFile.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); err != nil {
		lockFile.Close()
		return nil, fmt.Errorf("event log already has another writer: %w", err)
	}
	file, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		syscall.Flock(int(lockFile.Fd()), syscall.LOCK_UN)
		lockFile.Close()
		return nil, fmt.Errorf("open event log: %w", err)
	}
	info, err := file.Stat()
	if err != nil {
		file.Close()
		syscall.Flock(int(lockFile.Fd()), syscall.LOCK_UN)
		lockFile.Close()
		return nil, err
	}
	if err := syncJournalDirectory(filepath.Dir(path)); err != nil {
		file.Close()
		syscall.Flock(int(lockFile.Fd()), syscall.LOCK_UN)
		lockFile.Close()
		return nil, err
	}
	return &EventLog{file: file, lockFile: lockFile, acknowledgedSize: info.Size()}, nil
}

func syncJournalDirectory(path string) error {
	dir, err := os.Open(path)
	if err != nil {
		return err
	}
	defer dir.Close()
	return dir.Sync()
}

func (l *EventLog) Append(event LoggedEvent) error {
	if l == nil {
		return errors.New("event log is not initialized")
	}
	if event.SchemaVersion == 0 {
		event.SchemaVersion = EventLogSchemaVersion
	}
	if event.BrainIdentity == "" {
		event.BrainIdentity = BrainIdentity
	}
	data, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("encode logged event: %w", err)
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.file == nil || l.lockFile == nil {
		return errors.New("event log is not initialized")
	}
	// A workspace supervisor or external copier may replace an open path.
	// Appending to the old, unlinked inode would acknowledge lost history.
	opened, err := l.file.Stat()
	if err != nil {
		return err
	}
	visible, err := os.Stat(l.file.Name())
	if err != nil {
		return fmt.Errorf("journal pathname unavailable: %w", err)
	}
	if !os.SameFile(opened, visible) {
		return errors.New("journal pathname replaced while writer was open; recovery required")
	}
	if opened.Size() != l.acknowledgedSize || visible.Size() != l.acknowledgedSize {
		return errors.New("journal physical length changed outside writer; recovery required")
	}
	if l.beforeAppend != nil {
		if err := l.beforeAppend(event); err != nil {
			return fmt.Errorf("inject event log append failure: %w", err)
		}
	}
	if _, err := l.file.Write(append(data, '\n')); err != nil {
		return fmt.Errorf("append logged event: %w", err)
	}
	if l.transactionFault != nil {
		l.transactionFault("after-write-before-sync", event)
	}
	if err := l.file.Sync(); err != nil {
		return fmt.Errorf("sync event log: %w", err)
	}
	if l.transactionFault != nil {
		l.transactionFault("after-sync-before-apply", event)
	}
	expected := l.acknowledgedSize + int64(len(data)+1)
	opened, err = l.file.Stat()
	if err != nil {
		return err
	}
	visible, err = os.Stat(l.file.Name())
	if err != nil || !os.SameFile(opened, visible) || opened.Size() != expected || visible.Size() != expected {
		return errors.New("journal changed during append/fsync; recovery required")
	}
	l.acknowledgedSize = expected
	return nil
}

func (l *EventLog) Close() error {
	if l == nil {
		return nil
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	var closeErr error
	if l.file != nil {
		closeErr = l.file.Close()
		l.file = nil
	}
	if l.lockFile != nil {
		if err := syscall.Flock(int(l.lockFile.Fd()), syscall.LOCK_UN); err != nil && closeErr == nil {
			closeErr = err
		}
		if err := l.lockFile.Close(); err != nil && closeErr == nil {
			closeErr = err
		}
		l.lockFile = nil
	}
	return closeErr
}

// RepairConflictingSequences repairs a legacy log written by multiple runtimes
// that each maintained their own sequence counter. It only proceeds when every
// record is valid, physical append order is non-decreasing by the old sequence,
// and the distinct old sequences form a complete range starting at 1. It keeps
// every record, assigns a single global sequence in physical append order, and
// writes an exact backup before atomically replacing the active log.
//
// The caller must hold the EventLog writer lock for the duration of recovery.
func (l *EventLog) RepairConflictingSequences() (string, error) {
	if l == nil {
		return "", errors.New("event log is not initialized")
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.file == nil || l.lockFile == nil {
		return "", errors.New("event log writer lock is not held")
	}

	path := l.file.Name()
	data, err := os.ReadFile(path)
	if err != nil {
		return "", fmt.Errorf("read event log for recovery: %w", err)
	}
	if len(data) == 0 {
		return "", errors.New("cannot repair an empty event log")
	}

	rawLines := bytes.Split(data, []byte{'\n'})
	if len(rawLines) > 0 && len(rawLines[len(rawLines)-1]) == 0 {
		rawLines = rawLines[:len(rawLines)-1]
	}
	if len(rawLines) == 0 {
		return "", errors.New("event log contains no records")
	}

	events := make([]LoggedEvent, 0, len(rawLines))
	seen := make(map[uint64][]byte)
	var previous, maxSequence uint64
	conflicts := 0
	for i, raw := range rawLines {
		lineNumber := i + 1
		if len(raw) == 0 {
			return "", fmt.Errorf("cannot repair blank event log record at line %d", lineNumber)
		}
		var event LoggedEvent
		if err := json.Unmarshal(raw, &event); err != nil {
			return "", fmt.Errorf("cannot repair malformed event at line %d: %w", lineNumber, err)
		}
		if !supportedEventLogSchema(event.SchemaVersion) {
			return "", fmt.Errorf("cannot repair unsupported schema version %d at line %d", event.SchemaVersion, lineNumber)
		}
		if err := validateJournalPayload(event); err != nil {
			return "", fmt.Errorf("cannot repair invalid payload at line %d: %w", lineNumber, err)
		}
		if event.BrainIdentity != BrainIdentity {
			return "", fmt.Errorf("cannot repair event for brain %q at line %d", event.BrainIdentity, lineNumber)
		}
		if event.SchemaVersion >= compositionJournalSchemaVersion || event.Type == EventTypeSensorIntent || event.Type == EventTypeSensorCommit || event.Type == EventTypeKnowledgeImport || event.Type == EventTypeVectorGround || event.Type == EventTypeObservation || event.Type == EventTypeCognitiveProcess || event.Type == EventTypeCognitiveThink || event.Type == EventTypeActionBinding || event.Type == EventTypeInquiryOutcome || event.Type == EventTypeSurfaceRebinding || event.Type == EventTypeWrittenGroundingMigration || event.Type == EventTypeSpellingExposure {
			return "", fmt.Errorf("cannot repair transactional sensor records at line %d using legacy sequence renumbering", lineNumber)
		}
		if event.Sequence == 0 {
			return "", fmt.Errorf("cannot repair zero event sequence at line %d", lineNumber)
		}
		if lineNumber == 1 && event.Sequence != 1 {
			return "", fmt.Errorf("cannot repair log whose first sequence is %d", event.Sequence)
		}
		if event.Sequence < previous {
			return "", fmt.Errorf("cannot safely repair non-monotonic sequence %d at line %d after %d", event.Sequence, lineNumber, previous)
		}
		previous = event.Sequence
		if event.Sequence > maxSequence {
			maxSequence = event.Sequence
		}
		canonical, err := json.Marshal(event)
		if err != nil {
			return "", fmt.Errorf("normalize event at line %d: %w", lineNumber, err)
		}
		if prior, exists := seen[event.Sequence]; exists {
			if !bytes.Equal(prior, canonical) {
				conflicts++
			}
		} else {
			seen[event.Sequence] = canonical
		}
		events = append(events, event)
	}
	if conflicts == 0 {
		return "", errors.New("event log has no conflicting duplicate sequences to repair")
	}
	if uint64(len(seen)) != maxSequence {
		return "", fmt.Errorf("cannot safely repair sequence gaps: found %d distinct sequences with maximum %d", len(seen), maxSequence)
	}

	// Keep all events and their payloads. The line order is the durable append
	// order, so assign one monotonically increasing sequence across that order.
	var repaired bytes.Buffer
	for i := range events {
		events[i].Sequence = uint64(i + 1)
		record, err := json.Marshal(events[i])
		if err != nil {
			return "", fmt.Errorf("encode recovered event %d: %w", i+1, err)
		}
		repaired.Write(record)
		repaired.WriteByte('\n')
	}

	backupPath := fmt.Sprintf("%s.conflict-backup-%s", path, time.Now().UTC().Format("20060102T150405.000000000Z"))
	backup, err := os.OpenFile(backupPath, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return "", fmt.Errorf("create event log recovery backup: %w", err)
	}
	if _, err := backup.Write(data); err != nil {
		backup.Close()
		os.Remove(backupPath)
		return "", fmt.Errorf("write event log recovery backup: %w", err)
	}
	if err := backup.Sync(); err != nil {
		backup.Close()
		os.Remove(backupPath)
		return "", fmt.Errorf("sync event log recovery backup: %w", err)
	}
	if err := backup.Close(); err != nil {
		os.Remove(backupPath)
		return "", fmt.Errorf("close event log recovery backup: %w", err)
	}

	temp, err := os.CreateTemp(filepath.Dir(path), ".horizon-event-log-recovery-*.tmp")
	if err != nil {
		return "", fmt.Errorf("create recovered event log: %w", err)
	}
	tempPath := temp.Name()
	defer os.Remove(tempPath)
	if _, err := temp.Write(repaired.Bytes()); err != nil {
		temp.Close()
		return "", fmt.Errorf("write recovered event log: %w", err)
	}
	if err := temp.Sync(); err != nil {
		temp.Close()
		return "", fmt.Errorf("sync recovered event log: %w", err)
	}
	if err := temp.Close(); err != nil {
		return "", fmt.Errorf("close recovered event log: %w", err)
	}

	// Keep the inter-process lock file open while replacing only the data file.
	if err := l.file.Close(); err != nil {
		l.file = nil
		return "", fmt.Errorf("close old event log before recovery: %w", err)
	}
	l.file = nil
	if err := os.Rename(tempPath, path); err != nil {
		reopened, reopenErr := os.OpenFile(path, os.O_APPEND|os.O_WRONLY, 0600)
		if reopenErr == nil {
			l.file = reopened
			if st, e := reopened.Stat(); e == nil {
				l.acknowledgedSize = st.Size()
			}
		}
		return "", fmt.Errorf("atomically replace event log: %w", err)
	}
	reopened, err := os.OpenFile(path, os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return "", fmt.Errorf("reopen recovered event log (backup at %s): %w", backupPath, err)
	}
	l.file = reopened
	if st, e := reopened.Stat(); e == nil {
		l.acknowledgedSize = st.Size()
	} else {
		return "", e
	}
	if err := syncJournalDirectory(filepath.Dir(path)); err != nil {
		return "", err
	}
	return backupPath, nil
}

// ErrUncommittedSensorTransaction indicates that a durable intent does not
// have a matching commit marker. It must not be silently replayed.
var ErrUncommittedSensorTransaction = errors.New("uncommitted sensor transaction")

func sensorIntentHash(intent LoggedEvent) (string, error) {
	data, err := json.Marshal(intent)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(data)
	return fmt.Sprintf("%x", sum[:]), nil
}

// ReadEventLog preserves the v1 event stream while interpreting a committed
// sensor intent/commit pair as one logical process event with one sequence.
// An orphan, interrupted, or mismatched pair is an error, not a successful
// observation. A caller must recover from a known-good checkpoint/log.
func ReadEventLog(path string) ([]LoggedEvent, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var events []LoggedEvent
	var expected uint64 = 1
	type eventKey struct {
		sequence  uint64
		eventType string
	}
	seen := make(map[eventKey][]byte)
	var pending *LoggedEvent
	var pendingHash string
	scanner := bufio.NewScanner(file)
	scanner.Buffer(make([]byte, 64*1024), 16*1024*1024)
	for lineNumber := 1; scanner.Scan(); lineNumber++ {
		line := append([]byte(nil), scanner.Bytes()...)
		var event LoggedEvent
		if err := json.Unmarshal(line, &event); err != nil {
			return nil, fmt.Errorf("decode event log at line %d: %w", lineNumber, err)
		}
		if !supportedEventLogSchema(event.SchemaVersion) {
			return nil, fmt.Errorf("unsupported event log schema version %d at line %d", event.SchemaVersion, lineNumber)
		}
		if event.BrainIdentity != BrainIdentity {
			return nil, fmt.Errorf("event belongs to brain %q at line %d", event.BrainIdentity, lineNumber)
		}
		canonical, err := json.Marshal(event)
		if err != nil {
			return nil, fmt.Errorf("normalize event at line %d: %w", lineNumber, err)
		}
		key := eventKey{sequence: event.Sequence, eventType: event.Type}
		if event.Sequence < expected {
			// Preserve legacy nonadjacent idempotent duplicate recovery, but
			// require identical bytes and the same physical record type.
			if prior, ok := seen[key]; ok && bytes.Equal(prior, canonical) {
				continue
			}
			return nil, fmt.Errorf("conflicting or unknown duplicate event sequence %d type %q at line %d", event.Sequence, event.Type, lineNumber)
		}
		if event.Sequence > expected || event.Sequence == 0 {
			return nil, fmt.Errorf("event sequence discontinuity at line %d: got %d want %d", lineNumber, event.Sequence, expected)
		}

		if pending != nil {
			if err := validateJournalPayload(event); err != nil {
				return nil, fmt.Errorf("invalid sensor commit at line %d: %w", lineNumber, err)
			}
			if event.Type != EventTypeSensorCommit {
				return nil, fmt.Errorf("%w: sensor intent at sequence %d interrupted by %q at line %d", ErrUncommittedSensorTransaction, expected, event.Type, lineNumber)
			}
			if event.IntentHash == "" || event.IntentHash != pendingHash || event.Event != nil ||
				event.Experience != nil || event.KnowledgeDocument != nil || event.Vector != nil || event.Outcome != nil || event.Consequence != nil || event.ObservationCommand != nil || event.ActionBinding != nil || event.InquiryOutcome != nil ||
				!event.Timestamp.Equal(pending.Timestamp) || event.DynamicsEncoding != pending.DynamicsEncoding || event.SurfaceEncoding != pending.SurfaceEncoding || event.CompositionEncoding != pending.CompositionEncoding {
				return nil, fmt.Errorf("%w: sensor commit mismatch at line %d", ErrUncommittedSensorTransaction, lineNumber)
			}
			seen[key] = canonical
			committed := *pending
			committed.Type = EventTypeProcess
			committed.IntentHash = ""
			events = append(events, committed)
			pending = nil
			pendingHash = ""
			expected++
			continue
		}

		if err := validateJournalPayload(event); err != nil {
			return nil, fmt.Errorf("invalid journal payload at line %d: %w", lineNumber, err)
		}
		switch event.Type {
		case EventTypeSurfaceRebinding, EventTypeWrittenGroundingMigration, EventTypeSpellingExposure, EventTypeCompositionMigration, EventTypeCompositionExposure, EventTypeCompositionPerception:
			seen[key] = canonical
			events = append(events, event)
			expected++
		case EventTypeInquiryOutcome:
			if event.Timestamp.IsZero() || event.Event == nil || !event.Event.Timestamp.Equal(event.Timestamp) || event.Experience != nil || event.KnowledgeDocument != nil || event.Vector != nil || event.Outcome != nil || event.Consequence != nil || event.IntentHash != "" {
				return nil, fmt.Errorf("invalid inquiry outcome command at line %d", lineNumber)
			}
			if err := validateInquiryOutcomeCommand(event.Event, event.InquiryOutcome); err != nil {
				return nil, fmt.Errorf("invalid inquiry outcome command at line %d: %w", lineNumber, err)
			}
			seen[key] = canonical
			events = append(events, event)
			expected++
		case EventTypeActionBinding:
			if event.ActionBinding == nil || event.ActionBinding.RequestID == "" || event.ActionBinding.BrainIdentity != BrainIdentity || event.Event != nil || event.Experience != nil || event.KnowledgeDocument != nil || event.Vector != nil || event.Outcome != nil || event.Consequence != nil || event.IntentHash != "" || event.Timestamp.IsZero() {
				return nil, fmt.Errorf("invalid action binding command at line %d", lineNumber)
			}
			seen[key] = canonical
			events = append(events, event)
			expected++
		case EventTypeObservation:
			if event.Timestamp.IsZero() || event.Event == nil || !event.Event.Timestamp.Equal(event.Timestamp) || event.Experience != nil || event.KnowledgeDocument != nil || event.Vector != nil || event.Outcome != nil || event.Consequence != nil || event.IntentHash != "" {
				return nil, fmt.Errorf("invalid observation command at line %d", lineNumber)
			}
			if err := validateObservationCommand(event.Event, event.ObservationCommand); err != nil {
				return nil, fmt.Errorf("invalid observation command at line %d: %w", lineNumber, err)
			}
			seen[key] = canonical
			events = append(events, event)
			expected++
		case EventTypeCognitiveProcess, EventTypeCognitiveThink:
			if event.Event == nil || event.Timestamp.IsZero() || !event.Timestamp.Equal(event.Event.Timestamp) || event.Event.SensorObservation != nil || event.Experience != nil || event.KnowledgeDocument != nil || event.Vector != nil || event.Outcome != nil || event.Consequence != nil || event.IntentHash != "" {
				return nil, fmt.Errorf("invalid cognitive command at line %d", lineNumber)
			}
			seen[key] = canonical
			events = append(events, event)
			expected++
		case EventTypeVectorGround:
			if event.Vector == nil || event.Event != nil || event.Experience != nil ||
				event.KnowledgeDocument != nil || event.Outcome != nil ||
				event.Consequence != nil || event.IntentHash != "" || event.Timestamp.IsZero() {
				return nil, fmt.Errorf("invalid numeric grounding record at line %d", lineNumber)
			}
			if err := validateGroundVector(*event.Vector); err != nil {
				return nil, fmt.Errorf("invalid numeric grounding vector at line %d: %w", lineNumber, err)
			}
			seen[key] = canonical
			events = append(events, event)
			expected++
		case EventTypeKnowledgeImport:
			if event.KnowledgeDocument == nil || event.Event != nil ||
				event.Experience != nil || event.Outcome != nil ||
				event.Consequence != nil || event.Vector != nil || event.IntentHash != "" ||
				event.Timestamp.IsZero() {
				return nil, fmt.Errorf("invalid knowledge import record at line %d", lineNumber)
			}
			if _, err := knowledge.CompileKnowledgeDocumentWithEncoding(*event.KnowledgeDocument, event.Timestamp, event.SurfaceEncoding); err != nil {
				return nil, fmt.Errorf("invalid knowledge import document at line %d: %w", lineNumber, err)
			}
			seen[key] = canonical
			events = append(events, event)
			expected++
		case EventTypeSensorIntent:
			if event.Event == nil || event.Event.SensorObservation == nil ||
				event.Event.ID == "" || event.Event.ID != event.Event.SensorObservation.SampleID ||
				!event.Timestamp.Equal(event.Event.Timestamp) ||
				!event.Timestamp.Equal(event.Event.SensorObservation.Timestamp) ||
				event.IntentHash != "" || event.KnowledgeDocument != nil || event.Vector != nil {
				return nil, fmt.Errorf("invalid sensor intent payload at line %d", lineNumber)
			}
			if err := event.Event.SensorObservation.Validate(); err != nil {
				return nil, fmt.Errorf("invalid sensor state at line %d: %w", lineNumber, err)
			}
			digest, err := sensorIntentHash(event)
			if err != nil {
				return nil, fmt.Errorf("hash sensor intent at line %d: %w", lineNumber, err)
			}
			pending = &event
			pendingHash = digest
			seen[key] = canonical
		case EventTypeSensorCommit:
			return nil, fmt.Errorf("%w: sensor commit without intent at line %d", ErrUncommittedSensorTransaction, lineNumber)
		default:
			seen[key] = canonical
			events = append(events, event)
			expected++
		}
	}
	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("read event log: %w", err)
	}
	if pending != nil {
		return nil, fmt.Errorf("%w: sensor intent sequence %d has no commit marker", ErrUncommittedSensorTransaction, pending.Sequence)
	}
	return events, nil
}

// ReplayEventLog re-applies durable events to the same neural substrate. The
// source log is temporarily detached so replay cannot append duplicate events.
// Replay is intended as a recovery operation and should not run concurrently
// with normal runtime mutation.
func ReplayEventLog(brainRuntime *BrainRuntime, events []LoggedEvent) error {
	return replayEventLogFromSequence(brainRuntime, events, 1)
}

// replayEventLogFromSequence is used for *isolated* checkpoint recovery.
// The caller must not expose brainRuntime to concurrent writers during replay.
func replayEventLogFromSequence(brainRuntime *BrainRuntime, events []LoggedEvent, firstSequence uint64) error {
	if brainRuntime == nil {
		return errors.New("brain runtime is nil")
	}
	if firstSequence == 0 {
		return errors.New("replay sequence must start at 1 or later")
	}
	if brainRuntime.LastSequence() != firstSequence-1 {
		return fmt.Errorf("replay target sequence %d does not precede first event %d", brainRuntime.LastSequence(), firstSequence)
	}
	// Validate the entire supplied batch before applying its first command.
	// Rebuild helpers additionally verify physical framing through ReadEventLog.
	for _, logged := range events {
		if err := validateJournalPayload(logged); err != nil {
			return err
		}
	}
	brainRuntime.mu.Lock()
	if brainRuntime.supervised || brainRuntime.eventLog != nil || brainRuntime.replaying {
		brainRuntime.mu.Unlock()
		return ErrManagedRuntimeAccess
	}
	if err := brainRuntime.ensureWritableLocked(); err != nil {
		brainRuntime.mu.Unlock()
		return err
	}
	// Validate the whole contract timeline before the first mutation. A v2
	// command cannot bypass its migration, nor can serving silently revert.
	migrated := brainRuntime.neuralWrittenGrounding
	compositionEncoding := ""
	if brainRuntime.composition != nil {
		compositionEncoding = brainRuntime.composition.Config.Version
	}
	contractSequence := firstSequence
	for _, logged := range events {
		if logged.BrainIdentity != BrainIdentity || !supportedEventLogSchema(logged.SchemaVersion) || logged.Sequence != contractSequence {
			brainRuntime.mu.Unlock()
			return errors.New("incompatible identity/schema or discontinuous replay sequence")
		}
		contractSequence++
		if logged.CompositionEncoding != compositionEncoding {
			brainRuntime.mu.Unlock()
			return errors.New("composition contract changed without its migration")
		}
		if logged.Type == EventTypeCompositionMigration {
			if compositionEncoding != "" {
				brainRuntime.mu.Unlock()
				return errors.New("duplicate composition migration")
			}
			compositionEncoding = logged.CompositionMigration.Plan.Config.Version
		}
		if (logged.SurfaceEncoding == knowledge.NeuralWrittenEncoding) != migrated {
			brainRuntime.mu.Unlock()
			return errors.New("written grounding contract changed without its migration")
		}
		if logged.Type == EventTypeWrittenGroundingMigration {
			if migrated {
				brainRuntime.mu.Unlock()
				return errors.New("duplicate written grounding migration")
			}
			migrated = true
		}
	}
	originalLog := brainRuntime.eventLog
	originalEncoding := brainRuntime.surfaceEncoding
	originalDynamics := brainRuntime.dynamicsEncoding
	brainRuntime.eventLog = nil
	brainRuntime.replaying = true
	brainRuntime.mu.Unlock()
	complete := false
	defer func() {
		brainRuntime.mu.Lock()
		brainRuntime.replaying = false
		if !complete {
			brainRuntime.markRecoveryRequiredLocked()
		}
		brainRuntime.eventLog = originalLog
		brainRuntime.surfaceEncoding = originalEncoding
		if brainRuntime.neuralWrittenGrounding {
			brainRuntime.surfaceEncoding = knowledge.NeuralWrittenEncoding
		}
		brainRuntime.dynamicsEncoding = originalDynamics
		brainRuntime.mu.Unlock()
	}()

	var expected uint64 = firstSequence
	for _, logged := range events {
		if logged.BrainIdentity != BrainIdentity {
			return fmt.Errorf("cannot replay event for brain %q", logged.BrainIdentity)
		}
		if !supportedEventLogSchema(logged.SchemaVersion) {
			return fmt.Errorf("unsupported event log schema version %d", logged.SchemaVersion)
		}
		if logged.Sequence != expected {
			return fmt.Errorf("replay sequence discontinuity: got %d want %d", logged.Sequence, expected)
		}
		expected++
		brainRuntime.mu.Lock()
		brainRuntime.surfaceEncoding = logged.SurfaceEncoding
		brainRuntime.dynamicsEncoding = logged.DynamicsEncoding
		brainRuntime.mu.Unlock()
		switch logged.Type {
		case EventTypeNativeControl:
			if _, err := brainRuntime.ApplyNativeControl(*logged.NativeControl, logged.Timestamp); err != nil {
				return err
			}
		case EventTypeCognitiveModel:
			if _, err := brainRuntime.ApplyCognitiveModel(*logged.CognitiveModel, logged.Timestamp); err != nil {
				return err
			}
		case EventTypeCompositionMigration:
			brainRuntime.mu.Lock()
			err := brainRuntime.applyCompositionMigrationLocked(*logged.CompositionMigration, logged.Timestamp)
			brainRuntime.mu.Unlock()
			if err != nil {
				return err
			}
		case EventTypeCompositionPerception:
			if _, err := brainRuntime.ObserveCompositionInput(*logged.CompositionPerception, logged.Timestamp); err != nil {
				return err
			}
		case EventTypeCompositionExposure:
			if _, err := brainRuntime.LearnComposition(*logged.CompositionExposure, logged.Timestamp); err != nil {
				return err
			}
		case EventTypeSpellingExposure:
			if _, err := brainRuntime.LearnSpelling(*logged.SpellingExposure, logged.Timestamp); err != nil {
				return err
			}
		case EventTypeWrittenGroundingMigration:
			if err := brainRuntime.replayWrittenGroundingMigration(*logged.WrittenGroundingMigration, logged.Timestamp); err != nil {
				return err
			}
		case EventTypeSurfaceRebinding:
			if err := brainRuntime.ApplyWrittenSurfaceRebinding(*logged.SurfaceRebinding, logged.Timestamp); err != nil {
				return err
			}
		case EventTypeVectorGround:
			if logged.Vector == nil {
				return errors.New("numeric grounding record has no vector")
			}
			if _, err := brainRuntime.GroundVectorAt(*logged.Vector, logged.Timestamp); err != nil {
				return fmt.Errorf("replay numeric grounding at sequence %d: %w", logged.Sequence, err)
			}
		case EventTypeKnowledgeImport:
			if logged.KnowledgeDocument == nil {
				return errors.New("knowledge import event has no document")
			}
			if err := brainRuntime.replayKnowledgeDocument(*logged.KnowledgeDocument, logged.Timestamp); err != nil {
				return fmt.Errorf("replay knowledge import at sequence %d: %w", logged.Sequence, err)
			}
		case EventTypeLearn:
			if logged.Experience == nil {
				return errors.New("learn event has no experience")
			}
			if _, err := brainRuntime.LearnExperience(*logged.Experience, logged.Timestamp); err != nil {
				return err
			}
		case EventTypeInquiryOutcome:
			if err := validateInquiryOutcomeCommand(logged.Event, logged.InquiryOutcome); err != nil {
				return err
			}
			if _, _, _, err := brainRuntime.processInquiryOutcomeCommand(*logged.Event, *logged.InquiryOutcome); err != nil {
				return err
			}
		case EventTypeActionBinding:
			if logged.ActionBinding == nil {
				return errors.New("action binding command has no binding")
			}
			if err := brainRuntime.RegisterActionBinding(*logged.ActionBinding); err != nil {
				return err
			}
		case EventTypeObservation:
			if err := validateObservationCommand(logged.Event, logged.ObservationCommand); err != nil {
				return err
			}
			if _, _, err := brainRuntime.processObservationCommand(*logged.Event, *logged.ObservationCommand); err != nil {
				return err
			}
		case EventTypeCognitiveProcess:
			if logged.Event == nil {
				return errors.New("cognitive process has no event")
			}
			if _, err := brainRuntime.CognitiveProcess(*logged.Event); err != nil {
				return err
			}
		case EventTypeCognitiveThink:
			if logged.Event == nil {
				return errors.New("cognitive think has no event")
			}
			brainRuntime.mu.Lock()
			_, err := brainRuntime.cognitiveThinkAtLocked(logged.Event.Cycles, logged.Timestamp, true)
			brainRuntime.mu.Unlock()
			if err != nil {
				return err
			}
		case EventTypeProcess:
			if logged.Event == nil {
				return errors.New("process event has no event payload")
			}
			if logged.Event.SensorObservation != nil {
				// Sensor processing includes deterministic projection into the canonical
				// substrate before cognitive processing. Re-run the complete boundary,
				// not only the downstream event with previously assigned node IDs.
				orchestrator := NewCognitiveOrchestrator(brainRuntime)
				if _, err := orchestrator.ProcessSensorObservation(*logged.Event.SensorObservation); err != nil {
					return fmt.Errorf("replay sensor observation %q: %w", logged.Event.SensorObservation.SampleID, err)
				}
			} else {
				event := cloneEvent(*logged.Event)
				if event.Timestamp.IsZero() {
					event.Timestamp = logged.Timestamp
				}
				if _, _, err := brainRuntime.Process(*event); err != nil {
					return err
				}
			}
		case EventTypeThink:
			if logged.Event == nil {
				return errors.New("think event has no event payload")
			}
			if _, _, err := brainRuntime.thinkAtWithContext(logged.Event.Cycles, logged.Event.Context, logged.Timestamp); err != nil {
				return err
			}
		case EventTypeOutcome:
			if logged.Outcome == nil {
				return errors.New("outcome event has no outcome payload")
			}
			if _, err := brainRuntime.ObserveOutcome(*logged.Outcome); err != nil {
				return err
			}
		case EventTypeConsequence:
			if logged.Consequence == nil {
				return errors.New("consequence event has no consequence payload")
			}
			if _, err := brainRuntime.RecordInquiryConsequenceEvent(*logged.Consequence, logged.Timestamp); err != nil {
				return err
			}
		default:
			return fmt.Errorf("unknown event type %q", logged.Type)
		}
		if got := brainRuntime.LastSequence(); got != logged.Sequence {
			return fmt.Errorf("replay event sequence mismatch after %q: got %d want %d", logged.Type, got, logged.Sequence)
		}
	}
	complete = true
	return nil
}
