package runtime

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/project-horizon/horizon-core/services/ai/activation"
	"github.com/project-horizon/horizon-core/services/ai/knowledge"
	"github.com/project-horizon/horizon-core/services/ai/learning"
)

const physicalMemoryBrainSnapshotSchemaVersion = 10
const observedFeedbackBrainSnapshotSchemaVersion = 11
const evidenceProvenanceBrainSnapshotSchemaVersion = 12
const neuralWrittenBrainSnapshotSchemaVersion = 13
const BrainSnapshotSchemaVersion = neuralWrittenBrainSnapshotSchemaVersion
const recurrentBrainSnapshotSchemaVersion = 9
const orderedBrainSnapshotSchemaVersion = 8
const outcomeBrainSnapshotSchemaVersion = 7
const neuralBrainSnapshotSchemaVersion = 6
const priorBrainSnapshotSchemaVersion = 5
const legacyBrainSnapshotSchemaVersion = 4

type BrainSnapshot struct {
	Composition            *CompositionContinuation         `json:"composition,omitempty"`
	NeuralWrittenGrounding bool                             `json:"neural_written_grounding,omitempty"`
	ActionBindings         map[string]ActionBinding         `json:"action_bindings,omitempty"`
	EvidenceLedger         *learning.EvidenceLedgerSnapshot `json:"evidence_ledger,omitempty"`
	SchemaVersion          int                              `json:"schema_version"`
	BrainIdentity          string                           `json:"brain_identity"`
	Sequence               uint64                           `json:"sequence"`
	Timestamp              time.Time                        `json:"timestamp"`
	Checksum               string                           `json:"checksum"`
	Brain                  json.RawMessage                  `json:"brain"`
	Activation             activation.StateSnapshot         `json:"activation"`
	CognitiveState         CognitiveState                   `json:"cognitive_state"`
	InquiryValence         map[InquiryAction]float64        `json:"inquiry_valence"`
	// Snapshot v5: temporal predecessor and dedup state must survive a restart.
	LastObservationPopulation []knowledge.NodeID `json:"last_observation_population,omitempty"`
	LastObservationAt         time.Time          `json:"last_observation_at,omitempty"`
	ProcessedEvents           map[string]uint64  `json:"processed_events,omitempty"`
	// Adapter-only provenance, stored in the checkpoint envelope rather than
	// the lexical-identity-free canonical Brain substrate.
	SurfaceAnnotations []knowledge.SurfaceAnnotation `json:"surface_annotations,omitempty"`
	// Empty for standalone checkpoints. Required for journal-offset recovery.
	JournalPrefixHash string `json:"journal_prefix_hash,omitempty"`
}

type checkpointPayload struct {
	Brain          json.RawMessage           `json:"brain"`
	Activation     activation.StateSnapshot  `json:"activation"`
	CognitiveState CognitiveState            `json:"cognitive_state"`
	InquiryValence map[InquiryAction]float64 `json:"inquiry_valence"`
}

// checkpointChecksum covers the complete logical neural/runtime state rather
// than only the serialized Brain graph. Envelope metadata is intentionally
// excluded so a checkpoint can be verified independently of its timestamp or
// sequence metadata.
func checkpointChecksum(brain json.RawMessage, state activation.StateSnapshot, cognitiveState CognitiveState, inquiryValence map[InquiryAction]float64) (string, error) {
	payload, err := json.Marshal(checkpointPayload{Brain: brain, Activation: state, CognitiveState: cognitiveState, InquiryValence: inquiryValence})
	if err != nil {
		return "", err
	}
	hash := sha256.Sum256(payload)
	return hex.EncodeToString(hash[:]), nil
}

// Checkpoint persists the neural substrate and the runtime's recurrent
// activation state. The latter is process state, not a second memory store;
// without it a restart would restore the graph but lose the ongoing thought.
func (r *BrainRuntime) Checkpoint(path string) error {
	if r == nil || r.brain == nil {
		return errors.New("brain runtime is not initialized")
	}
	if path == "" {
		return errors.New("checkpoint path is empty")
	}

	r.mu.Lock()
	defer r.mu.Unlock()
	if err := r.ensureWritableLocked(); err != nil {
		return err
	}
	return r.checkpointLocked(path)
}

// checkpointLocked is also used to persist a private pre-migration backup
// while the same owner lock protects its reference and journal receipt.
func (r *BrainRuntime) checkpointLocked(path string) error {
	if r.replaying {
		return errors.New("checkpoint requires completed private replay")
	}
	if r.brain.HasNativeControl() {
		return r.checkpointVersionLocked(path, nativeCheckpointSchemaVersion)
	}
	if r.brain.HasCoordinatedV5() {
		return r.checkpointVersionLocked(path, coordinatedCheckpointSchemaVersion)
	}
	if r.brain.HasPhase4V5() {
		return r.checkpointVersionLocked(path, phase4CheckpointSchemaVersion)
	}
	if r.brain.HasPhase2V5() {
		return r.checkpointVersionLocked(path, phase2CheckpointSchemaVersion)
	}
	if cfg, e := r.brain.CognitiveConfig(); e == nil {
		if cfg.Version == knowledge.CognitiveModelV2 {
			return r.checkpointVersionLocked(path, neuralMetaCheckpointSchemaVersion)
		}
		return r.checkpointVersionLocked(path, cognitiveModelCheckpointSchemaVersion)
	}
	if r.composition != nil {
		return r.checkpointVersionLocked(path, compositionBrainSnapshotSchemaVersion)
	}
	return r.checkpointVersionLocked(path, BrainSnapshotSchemaVersion)
}

func (r *BrainRuntime) checkpointVersionLocked(path string, version int) error {
	if r.brain.HasNativeControl() && version != nativeCheckpointSchemaVersion {
		return errors.New("native checkpoint downgrade")
	}
	if r.brain.HasCoordinatedV5() && version != coordinatedCheckpointSchemaVersion {
		return errors.New("coordinated snapshot downgrade")
	}
	if r.brain.HasPhase4V5() && version != phase4CheckpointSchemaVersion && version != coordinatedCheckpointSchemaVersion {
		return errors.New("Phase IV snapshot downgrade")
	}
	if r.brain.HasPhase2V5() && version < phase2CheckpointSchemaVersion {
		return errors.New("experimental phase2 checkpoint downgraded")
	}
	if cfg, e := r.brain.CognitiveConfig(); e == nil && cfg.Version == knowledge.CognitiveModelV2 && version < neuralMetaCheckpointSchemaVersion {
		return errors.New("V2 requires checkpoint schema 16")
	}
	if r.brain.HasCognitiveModel() && version < cognitiveModelCheckpointSchemaVersion {
		return errors.New("cognitive model requires checkpoint schema 15")
	}
	if r.composition != nil && version < compositionBrainSnapshotSchemaVersion {
		return errors.New("composition continuation requires checkpoint schema 14")
	}
	// Checkpoints must persist the ENTIRE canonical substrate, including
	// developmental experiences, bootstrap episodes, learned policy and
	// neural dynamics. The legacy nodes/patterns-only snapshot silently lost
	// these states and made checkpoint-offset replay diverge from live memory.

	activationState := r.activation.SnapshotState()
	cognitiveState := cloneCognitiveState(r.lastCognitiveState)
	inquiryValence := cloneInquiryValence(r.inquiryValence)
	// Journal anchoring is evaluated under the runtime lock, so no event may
	// advance r.seq between the snapshot and its durable prefix digest.
	journalHash, err := r.checkpointJournalPrefixLocked()
	if err != nil {
		return fmt.Errorf("anchor checkpoint to committed journal: %w", err)
	}
	ledger := r.evidence.Snapshot()
	snapshot := BrainSnapshot{
		Composition:               cloneCompositionState(r.composition),
		NeuralWrittenGrounding:    r.neuralWrittenGrounding,
		ActionBindings:            cloneActionBindings(r.actions),
		EvidenceLedger:            &ledger,
		SchemaVersion:             version,
		BrainIdentity:             BrainIdentity,
		Sequence:                  r.seq,
		Timestamp:                 r.nowLocked(),
		Activation:                activationState,
		CognitiveState:            cognitiveState,
		InquiryValence:            inquiryValence,
		LastObservationPopulation: append([]knowledge.NodeID(nil), r.lastObservationPopulation...),
		LastObservationAt:         r.lastObservationAt,
		ProcessedEvents:           cloneProcessedEventIndex(r.processedEvents),
		SurfaceAnnotations:        r.brain.SurfaceAnnotationsSnapshot(),
		JournalPrefixHash:         journalHash,
	}
	return r.writeCheckpointLocked(path, snapshot)
}

// RestoreCheckpoint loads a versioned checkpoint into the runtime's single
// existing Brain and restores its recurrent activation state. It never
// creates a second neural substrate.
func (r *BrainRuntime) RestoreCheckpoint(path string) error {
	if r == nil || r.brain == nil {
		return errors.New("brain runtime is not initialized")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	var snapshot BrainSnapshot
	if err := json.Unmarshal(data, &snapshot); err != nil {
		return fmt.Errorf("decode checkpoint: %w", err)
	}
	if snapshot.SchemaVersion != nativeCheckpointSchemaVersion && snapshot.SchemaVersion != coordinatedCheckpointSchemaVersion && snapshot.SchemaVersion != phase4CheckpointSchemaVersion && snapshot.SchemaVersion != phase2CheckpointSchemaVersion && snapshot.SchemaVersion != neuralMetaCheckpointSchemaVersion && snapshot.SchemaVersion != cognitiveModelCheckpointSchemaVersion && snapshot.SchemaVersion != compositionBrainSnapshotSchemaVersion && snapshot.SchemaVersion != BrainSnapshotSchemaVersion && snapshot.SchemaVersion != evidenceProvenanceBrainSnapshotSchemaVersion && snapshot.SchemaVersion != observedFeedbackBrainSnapshotSchemaVersion && snapshot.SchemaVersion != physicalMemoryBrainSnapshotSchemaVersion && snapshot.SchemaVersion != recurrentBrainSnapshotSchemaVersion && snapshot.SchemaVersion != orderedBrainSnapshotSchemaVersion && snapshot.SchemaVersion != outcomeBrainSnapshotSchemaVersion && snapshot.SchemaVersion != neuralBrainSnapshotSchemaVersion && snapshot.SchemaVersion != priorBrainSnapshotSchemaVersion && snapshot.SchemaVersion != legacyBrainSnapshotSchemaVersion {
		return fmt.Errorf("unsupported checkpoint schema version %d", snapshot.SchemaVersion)
	}
	if snapshot.SchemaVersion < neuralWrittenBrainSnapshotSchemaVersion && snapshot.NeuralWrittenGrounding {
		return errors.New("numeric written serving contract requires checkpoint schema 13")
	}
	if snapshot.Composition != nil && (snapshot.SchemaVersion < compositionBrainSnapshotSchemaVersion || !snapshot.NeuralWrittenGrounding) {
		return errors.New("composition requires checkpoint schema 14 and numeric written grounding")
	}
	var metaHeader struct {
		Model *knowledge.CognitiveModelState `json:"cognitive_model"`
	}
	if err := json.Unmarshal(snapshot.Brain, &metaHeader); err != nil {
		return err
	}
	if (metaHeader.Model != nil && metaHeader.Model.Phase2V5 != nil) != (snapshot.SchemaVersion == phase2CheckpointSchemaVersion || snapshot.SchemaVersion == phase4CheckpointSchemaVersion || snapshot.SchemaVersion == coordinatedCheckpointSchemaVersion) {
		return errors.New("phase2 state requires checkpoint17; historical state keeps original schema")
	}
	if (metaHeader.Model != nil && metaHeader.Model.Phase4V5 != nil) != (snapshot.SchemaVersion == phase4CheckpointSchemaVersion || snapshot.SchemaVersion == coordinatedCheckpointSchemaVersion) {
		return errors.New("Phase IV metadata requires snapshot18")
	}
	if metaHeader.Model != nil && metaHeader.Model.Config.Version == knowledge.CognitiveModelV2 && snapshot.SchemaVersion < neuralMetaCheckpointSchemaVersion {
		return errors.New("V2 checkpoint downgraded")
	}
	if (metaHeader.Model != nil && metaHeader.Model.Phase4V5 != nil && metaHeader.Model.Phase4V5.Contract != "") != (snapshot.SchemaVersion == coordinatedCheckpointSchemaVersion) {
		return errors.New("coordinated checkpoint19 required")
	}
	if err := knowledge.ValidateNativeControlState(snapshot.Brain, snapshot.SchemaVersion == nativeCheckpointSchemaVersion); err != nil {
		return err
	}
	if snapshot.SchemaVersion == nativeCheckpointSchemaVersion {
		var native struct {
			State *knowledge.NativeControlState `json:"native_control"`
		}
		if err := json.Unmarshal(snapshot.Brain, &native); err != nil {
			return err
		}
		if ep := native.State.Episode; ep != nil && len(ep.Decisions) > 0 && ep.Decisions[len(ep.Decisions)-1].After != knowledge.NativeStateDigest(snapshot.Activation.InternalState) {
			return errors.New("native checkpoint activity does not match trajectory")
		}
	}
	if err := knowledge.ValidateCognitiveModelState(snapshot.Brain, snapshot.SchemaVersion >= cognitiveModelCheckpointSchemaVersion && snapshot.SchemaVersion != nativeCheckpointSchemaVersion); err != nil {
		return err
	}
	if err := snapshot.Composition.validate(); err != nil {
		return err
	}
	version := ""
	if snapshot.Composition != nil {
		version = snapshot.Composition.Config.Version
	}
	if err := knowledge.ValidateCompositionState(snapshot.Brain, snapshot.Composition != nil, version); err != nil {
		return err
	}
	for _, annotation := range snapshot.SurfaceAnnotations {
		if err := annotation.Encoding.Validate(); err != nil {
			return fmt.Errorf("checkpoint adapter contract: %w", err)
		}
	}
	if snapshot.BrainIdentity != BrainIdentity {
		return fmt.Errorf("checkpoint belongs to brain %q", snapshot.BrainIdentity)
	}
	if snapshot.SchemaVersion < neuralBrainSnapshotSchemaVersion && len(snapshot.SurfaceAnnotations) > 0 {
		return errors.New("legacy checkpoint cannot carry unauthenticated adapter annotations")
	}
	if snapshot.SchemaVersion < outcomeBrainSnapshotSchemaVersion && (len(snapshot.ActionBindings) > 0 || snapshot.EvidenceLedger != nil) {
		return errors.New("legacy checkpoint cannot carry unauthenticated outcome state")
	}
	var ledger *learning.EvidenceLedger
	if snapshot.SchemaVersion >= outcomeBrainSnapshotSchemaVersion {
		if snapshot.EvidenceLedger == nil {
			return errors.New("checkpoint is missing outcome continuation state")
		}
		if snapshot.SchemaVersion < evidenceProvenanceBrainSnapshotSchemaVersion && len(snapshot.EvidenceLedger.Provenance) > 0 {
			return errors.New("typed evidence provenance requires checkpoint schema 12")
		}
	} else {
		ledger = learning.NewEvidenceLedger()
	}
	checksum, err := checkpointChecksumForSchema(snapshot)
	if err != nil {
		return fmt.Errorf("checksum checkpoint: %w", err)
	}
	if checksum != snapshot.Checksum {
		return errors.New("checkpoint checksum mismatch")
	}
	if snapshot.EvidenceLedger != nil {
		ledger, err = learning.RestoreEvidenceLedger(*snapshot.EvidenceLedger)
		if err != nil {
			return err
		}
	}
	if snapshot.SchemaVersion >= priorBrainSnapshotSchemaVersion {
		if (len(snapshot.LastObservationPopulation) == 0) != snapshot.LastObservationAt.IsZero() {
			return errors.New("checkpoint temporal population and timestamp disagree")
		}
		for id, seq := range snapshot.ProcessedEvents {
			if id == "" || seq == 0 || seq > snapshot.Sequence {
				return fmt.Errorf("checkpoint processed event index invalid for %q", id)
			}
		}
	}

	if err := knowledge.ValidateOrderedState(snapshot.Brain, snapshot.Activation.LastTrace, snapshot.SchemaVersion >= orderedBrainSnapshotSchemaVersion); err != nil {
		return fmt.Errorf("checkpoint neural contract: %w", err)
	}

	if err := knowledge.ValidateMemoryDecayState(snapshot.Brain, snapshot.SchemaVersion >= physicalMemoryBrainSnapshotSchemaVersion); err != nil {
		return fmt.Errorf("checkpoint memory contract: %w", err)
	}
	if err := knowledge.ValidateWrittenNumericState(snapshot.Brain, snapshot.NeuralWrittenGrounding); err != nil {
		return fmt.Errorf("checkpoint written grounding contract: %w", err)
	}
	if err := validateObservationPrediction(snapshot); err != nil {
		return err
	}
	if err := validateCheckpointContext(snapshot); err != nil {
		return err
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	// A poisoned runtime may have mutated neural state or runtime caches that
	// a checkpoint restore cannot safely unwind. Always use a new runtime.
	if err := r.ensureWritableLocked(); err != nil {
		return err
	}
	if r.eventLog != nil {
		return errors.New("checkpoint restore requires a detached runtime; use supervisor recovery")
	}
	if r.replaying || r.brain.HasNativeControl() {
		return errors.New("native checkpoint restore requires a fresh detached runtime")
	}
	staged, err := os.CreateTemp(filepath.Dir(path), ".horizon-restore-*.tmp")
	if err != nil {
		return err
	}
	brainPath := staged.Name()
	defer os.Remove(brainPath)
	if _, err := staged.Write(snapshot.Brain); err != nil {
		staged.Close()
		return fmt.Errorf("stage brain restore: %w", err)
	}
	if err := staged.Close(); err != nil {
		return err
	}
	if err := r.brain.Load(brainPath); err != nil {
		return fmt.Errorf("restore brain: %w", err)
	}
	if err := r.brain.RestoreSurfaceAnnotations(snapshot.SurfaceAnnotations); err != nil {
		r.markRecoveryRequiredLocked()
		return fmt.Errorf("%w: restore checkpoint adapter provenance: %v", ErrRuntimeRecoveryRequired, err)
	}
	actions := make(map[string]ActionBinding, len(snapshot.ActionBindings))
	for id, binding := range snapshot.ActionBindings {
		validated, bindingErr := r.validateActionBindingLocked(binding)
		if bindingErr != nil || id != binding.RequestID {
			r.markRecoveryRequiredLocked()
			return fmt.Errorf("%w: invalid checkpoint action binding %q", ErrRuntimeRecoveryRequired, id)
		}
		actions[id] = validated
	}
	if snapshot.EvidenceLedger != nil {
		for id := range snapshot.EvidenceLedger.ByNode {
			if r.brain.Registry.GetByID(id) == nil {
				r.markRecoveryRequiredLocked()
				return fmt.Errorf("%w: evidence targets an unknown node", ErrRuntimeRecoveryRequired)
			}
		}
	}
	r.inspectionEpoch = ""
	r.composition = cloneCompositionState(snapshot.Composition)
	r.neuralWrittenGrounding = snapshot.NeuralWrittenGrounding
	if r.neuralWrittenGrounding {
		r.surfaceEncoding = knowledge.NeuralWrittenEncoding
	} else {
		r.surfaceEncoding = knowledge.WrittenTextEncoding
	}
	r.actions, r.evidence = actions, ledger
	r.activation.RestoreState(snapshot.Activation)
	r.lastCognitiveState = cloneCognitiveState(snapshot.CognitiveState)
	r.inquiryValence = cloneInquiryValence(snapshot.InquiryValence)
	r.seq = snapshot.Sequence
	r.lastObservationPopulation = append([]knowledge.NodeID(nil), snapshot.LastObservationPopulation...)
	r.lastObservationAt = snapshot.LastObservationAt
	r.processedEvents = cloneProcessedEventIndex(snapshot.ProcessedEvents)
	r.cognitiveCommandIndex = nil
	r.nativeCommandIndex = nil
	return nil
}

func checkpointChecksumForSchema(snapshot BrainSnapshot) (string, error) {
	switch snapshot.SchemaVersion {
	case nativeCheckpointSchemaVersion, coordinatedCheckpointSchemaVersion, phase4CheckpointSchemaVersion, phase2CheckpointSchemaVersion, neuralMetaCheckpointSchemaVersion, cognitiveModelCheckpointSchemaVersion, compositionBrainSnapshotSchemaVersion:
		return checkpointChecksumV9(snapshot)
	case neuralWrittenBrainSnapshotSchemaVersion:
		return checkpointChecksumV8(snapshot)
	case legacyBrainSnapshotSchemaVersion:
		return checkpointChecksum(snapshot.Brain, snapshot.Activation, snapshot.CognitiveState, snapshot.InquiryValence)
	case priorBrainSnapshotSchemaVersion:
		return checkpointChecksumV5(snapshot)
	case neuralBrainSnapshotSchemaVersion:
		return checkpointChecksumV6(snapshot)
	default:
		return checkpointChecksumV7(snapshot)
	}
}

func cloneInquiryValence(in map[InquiryAction]float64) map[InquiryAction]float64 {
	out := make(map[InquiryAction]float64, len(in))
	for action, value := range in {
		out[action] = clampSigned(value)
	}
	return out
}
