package activation

import (
	"math"
	"time"

	"github.com/project-horizon/horizon-core/services/ai/knowledge"
)

const (
	predictionLearningRate  = 0.12
	predictionMinWeight     = 0.05
	predictionMaxWeight     = 0.95
	consequenceLearningRate = 0.08
)

func decayPredictionEligibility(eligibility float64, lastUpdate, now time.Time) float64 {
	eligibility = clamp01(eligibility)
	if eligibility <= 0 || lastUpdate.IsZero() || !now.After(lastUpdate) {
		return eligibility
	}
	const halfLife = time.Second
	factor := math.Exp(-math.Ln2 * now.Sub(lastUpdate).Seconds() / halfLife.Seconds())
	return clamp01(eligibility * factor)
}

// ApplyPredictionErrorPlasticity adapts existing neural connections from the
// mismatch between an internally predicted state and the state that actually
// occurred. It operates only on substrate dynamics; no semantic relation or
// cognitive rule is consulted. Eligibility is evaluated at the supplied
// timestamp using the same elapsed-time decay model as activity plasticity.
func (e *Engine) ApplyPredictionErrorPlasticity(predicted, actual map[knowledge.NodeID]float64, errorSignal float64, now time.Time) {
	e.applyPredictionErrorPlasticity(predicted, actual, errorSignal, now, false)
}

// Versioned local credit requires the source to participate in the compared
// states. Residual eligibility or a stale node.Activation cannot attribute an
// unrelated target's surprise to every incoming connection.
func (e *Engine) ApplyPredictionErrorPlasticityWithDynamics(predicted, actual map[knowledge.NodeID]float64, errorSignal float64, now time.Time, dynamics knowledge.DynamicsEncoding) {
	e.applyPredictionErrorPlasticity(predicted, actual, errorSignal, now, dynamics.HasLocalActivity())
}

func (e *Engine) applyPredictionErrorPlasticity(predicted, actual map[knowledge.NodeID]float64, errorSignal float64, now time.Time, local bool) {
	if e == nil || e.Memory == nil || errorSignal <= 0 {
		return
	}
	if now.IsZero() {
		now = time.Now().UTC()
	}
	errorSignal = clamp01(errorSignal)

	// Canonical brain mutation boundary. Memory optimization, checkpointing,
	// activation and all plasticity paths must serialize against the same
	// KnowledgeBase lock when they mutate canonical synapse state.
	e.Memory.Lock()
	defer e.Memory.Unlock()
	native := e.Memory.NativeOwnershipLocked()

	visit := func(source *knowledge.ConceptNode) {
		if local && max(clamp01(predicted[source.ID]), clamp01(actual[source.ID])) < activityPlasticityMinActive {
			return
		}
		for _, list := range source.Synapses {
			for _, synapse := range list {
				if synapse == nil || synapse.Inhibitory || (native.Enabled() && (native.Has(source.ID) || native.Has(synapse.TargetID))) {
					continue
				}
				targetActual := actual[synapse.TargetID]
				targetPredicted := predicted[synapse.TargetID]
				direction := targetActual - targetPredicted
				if abs(direction) < 0.001 {
					continue
				}

				eligibility := decayPredictionEligibility(synapse.Dynamic.Eligibility, synapse.Dynamic.LastEligibilityUpdate, now)
				if eligibility <= 0 {
					eligibility = clamp01(source.Activation * synapse.Activation)
				}
				if eligibility <= 0 {
					continue
				}

				synapse.Dynamic.Eligibility = eligibility
				if !local || synapse.Dynamic.LastEligibilityUpdate.IsZero() || now.After(synapse.Dynamic.LastEligibilityUpdate) {
					synapse.Dynamic.LastEligibilityUpdate = now
				}
				magnitude := predictionLearningRate * errorSignal * clamp01(abs(direction)) * eligibility
				if direction > 0 {
					synapse.Dynamic.Weight = clamp(synapse.Dynamic.Weight+magnitude, predictionMinWeight, predictionMaxWeight)
					synapse.Dynamic.Confidence = clamp01(synapse.Dynamic.Confidence + magnitude*0.5)
				} else {
					synapse.Dynamic.Weight = clamp(synapse.Dynamic.Weight-magnitude, predictionMinWeight, predictionMaxWeight)
					synapse.Dynamic.Confidence = clamp01(synapse.Dynamic.Confidence - magnitude*0.5)
				}
				synapse.Dynamic.LastModification = now

				synapse.Weight = synapse.Dynamic.Weight
				synapse.Confidence = synapse.Dynamic.Confidence
			}
		}
	}
	if local {
		ids := cloneState(predicted)
		for id, value := range actual {
			ids[id] = max(ids[id], value)
		}
		for id, value := range ids {
			if clamp01(value) < activityPlasticityMinActive {
				continue
			}
			if source := e.Memory.Registry.GetByID(id); source != nil {
				visit(source)
			}
		}
	} else {
		e.Memory.Registry.VisitNodes(visit)
	}

	// Prediction error also informs structural competition. This is a bounded
	// reconsolidation signal, not a semantic contradiction detector: competing
	// traces remain in the same Brain and retain their evidence history.
	e.Memory.Patterns.ReconsolidateFromState(predicted, actual, errorSignal)
}

// ApplyConsequencePlasticity reinforces or weakens already-eligible neural
// connections from the observed consequence of an inquiry. Information gain
// controls how strongly the consequence is retained; it never changes the
// sign of valence. No new connections are created.
func (e *Engine) ApplyConsequencePlasticity(valence, informationGain float64, now time.Time) {
	e.applyConsequencePlasticity(valence, informationGain, now, false)
}

func (e *Engine) ApplyConsequencePlasticityWithDynamics(valence, informationGain float64, now time.Time, dynamics knowledge.DynamicsEncoding) {
	e.applyConsequencePlasticity(valence, informationGain, now, dynamics.HasLocalActivity())
}

func (e *Engine) applyConsequencePlasticity(valence, informationGain float64, now time.Time, local bool) {
	if e == nil || e.Memory == nil || valence == 0 {
		return
	}
	if now.IsZero() {
		now = time.Now().UTC()
	}

	// Consequence learning mutates the same canonical synapse state as
	// prediction plasticity and memory optimization.
	e.Memory.Lock()
	defer e.Memory.Unlock()
	native := e.Memory.NativeOwnershipLocked()

	if valence < -1 {
		valence = -1
	} else if valence > 1 {
		valence = 1
	}
	informationGain = clamp01(informationGain)
	gain := 0.5 + 0.5*informationGain

	e.Memory.Registry.VisitNodes(func(source *knowledge.ConceptNode) {
		for _, list := range source.Synapses {
			for _, synapse := range list {
				if synapse == nil || synapse.Inhibitory || (native.Enabled() && (native.Has(source.ID) || native.Has(synapse.TargetID))) {
					continue
				}
				eligibility := decayPredictionEligibility(synapse.Dynamic.Eligibility, synapse.Dynamic.LastEligibilityUpdate, now)
				if eligibility <= 0 {
					continue
				}
				magnitude := consequenceLearningRate * abs(valence) * gain * eligibility
				if valence > 0 {
					synapse.Dynamic.Weight = clamp(synapse.Dynamic.Weight+magnitude, predictionMinWeight, predictionMaxWeight)
					synapse.Dynamic.Confidence = clamp01(synapse.Dynamic.Confidence + magnitude*0.5)
				} else {
					synapse.Dynamic.Weight = clamp(synapse.Dynamic.Weight-magnitude, predictionMinWeight, predictionMaxWeight)
					synapse.Dynamic.Confidence = clamp01(synapse.Dynamic.Confidence - magnitude*0.5)
				}
				synapse.Dynamic.LastModification = now
				if !local || synapse.Dynamic.LastEligibilityUpdate.IsZero() || now.After(synapse.Dynamic.LastEligibilityUpdate) {
					synapse.Dynamic.LastEligibilityUpdate = now
				}
				synapse.Dynamic.Eligibility = eligibility
				synapse.Weight = synapse.Dynamic.Weight
				synapse.Confidence = synapse.Dynamic.Confidence
			}
		}
	})
}
